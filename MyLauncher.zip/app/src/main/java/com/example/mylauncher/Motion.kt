package com.example.mylauncher

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring

/**
 * LauncherMotionSystem: طبقة مركزية موحّدة لمواصفات الحركة.
 * كل حركة في الواجهة تأخذ مواصفاتها من هنا، فيمكن تعديل "إحساس" الواجهة كلها من مكان واحد.
 * وإذا فعّل المستخدم "إزالة الحركات" في النظام تتحول الحركات إلى فورية.
 */
object LauncherMotionSystem {
    // مقياس الانكماش عند اللمس
    const val PRESS_SCALE = 0.92f

    // يُحدَّث عند كل عودة للواجهة
    @Volatile
    var reduced: Boolean = false

    fun refresh(context: Context) {
        reduced = Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1f
        ) == 0f
    }

    // انكماش اللمس: زنبرك سريع بارتداد خفيف
    fun press(): AnimationSpec<Float> =
        if (reduced) snap() else spring(dampingRatio = 0.55f, stiffness = 600f)

    // الاستقرار بعد الإفلات: ارتداد أنعم
    fun settle(): AnimationSpec<Float> =
        if (reduced) snap() else spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        )
}
