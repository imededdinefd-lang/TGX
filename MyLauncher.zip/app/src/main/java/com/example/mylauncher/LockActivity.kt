package com.example.mylauncher

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * شاشة قفل My Launcher.
 * ملاحظة أمان مهمة: هذه شاشة عرض فوق قفل النظام، وليست بديلاً عنه. أندرويد لا يسمح
 * لتطبيق عادي باستبدال قفل النظام، لذلك عند السحب للأعلى نطلب من النظام نفسه
 * رفع القفل (requestDismissKeyguard) فيظهر تحقق النظام الحقيقي: بصمة/وجه/نمط/PIN.
 */
class LockActivity : ComponentActivity() {

    private var preview = false

    // عند فتح القفل بالبصمة مباشرة (دون السحب) نغلق شاشتنا
    private val userPresent = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!preview) finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preview = intent.getBooleanExtra("preview", false)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        ContextCompat.registerReceiver(
            this, userPresent, IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        setContent { LockScreen(onUnlock = { unlock() }) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        preview = intent.getBooleanExtra("preview", false)
    }

    override fun onResume() {
        super.onResume()
        // إن لم يكن هناك قفل نظام فعلي (أو كنا في مهلة القفل) لا داعي لعرض الشاشة
        val power = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        if (!preview && power?.isInteractive == true && km?.isKeyguardLocked != true) finish()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(userPresent) }
        super.onDestroy()
    }

    private fun unlock() {
        if (preview) {
            finish()
            return
        }
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null || !km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissError() { finish() }
        })
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    // الإعدادات تُقرأ مرة عند الفتح
    val theme = remember { Prefs.load(context).theme }
    val pos = remember { Prefs.getInt(context, "lockPos", 1) }          // 0 أعلى، 1 وسط، 2 أسفل
    val weight = remember { Prefs.getInt(context, "lockStyle", 0) }     // 0 نحيف، 1 عريض
    val sizeIdx = remember { Prefs.getInt(context, "lockSize", 1) }     // 0 صغير، 1 متوسط، 2 كبير
    val showDate = remember { Prefs.getInt(context, "lockDate", 1) == 1 }
    val accent = AuroraThemes[theme.coerceIn(0, AuroraThemes.lastIndex)][1]

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    // الإزاحة تتبع الإصبع، وتُقرأ داخل graphicsLayer فقط (بلا إعادة تركيب)
    val off = remember { Animatable(0f) }
    val threshold = with(density) { 140.dp.toPx() }

    BackHandler { }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        val fire = off.value < -threshold
                        if (fire) onUnlock()
                        scope.launch { off.animateTo(0f, spring()) }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, spring()) } },
                    onVerticalDrag = { change, d ->
                        change.consume()
                        scope.launch { off.snapTo((off.value + d).coerceAtMost(0f)) }
                    }
                )
            }
    ) {
        AuroraBackground(theme)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.18f)))

        Box(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .graphicsLayer {
                    translationY = off.value
                    alpha = 1f - (-off.value / (3f * threshold)).coerceIn(0f, 0.8f)
                }
        ) {
            // الساعة والتاريخ: الموضع والنمط والحجم من الإعدادات
            Column(
                modifier = Modifier
                    .align(
                        when (pos) {
                            0 -> Alignment.TopCenter
                            2 -> Alignment.BottomCenter
                            else -> Alignment.Center
                        }
                    )
                    .padding(top = 72.dp, bottom = 150.dp, start = 24.dp, end = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // مؤشّر التوقيع بلون الثيم
                Box(
                    Modifier
                        .width(34.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(accent)
                )
                Text(
                    text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
                    color = Color.White,
                    fontSize = when (sizeIdx) { 0 -> 64.sp; 2 -> 104.sp; else -> 84.sp },
                    fontWeight = if (weight == 1) FontWeight.Bold else FontWeight.ExtraLight
                )
                if (showDate) {
                    Text(
                        text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // تلميح الفتح
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 44.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .width(44.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.White.copy(alpha = 0.55f))
                )
                Text("اسحب للأعلى للفتح", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            }
        }
    }
}
