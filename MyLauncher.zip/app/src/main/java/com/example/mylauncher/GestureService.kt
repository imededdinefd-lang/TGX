package com.example.mylauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

// أرقام الوظائف المتاحة للإيماءات
object GestureAction {
    const val NONE = 0
    const val BACK = 1
    const val HOME = 2
    const val RECENTS = 3
    const val NOTIFICATIONS = 4
    const val LOCK = 5
}

// محرّك الإيماءات: شرائح شفافة رفيعة فوق كل التطبيقات (TYPE_ACCESSIBILITY_OVERLAY)
// وتنفيذ أوامر النظام عبر الأفعال العامة لخدمة إمكانية الوصول.
class GestureService : AccessibilityService() {

    private var wm: WindowManager? = null
    private val views = mutableListOf<View>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rebuild()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeOverlays()
        instance = null
        return super.onUnbind(intent)
    }

    private fun removeOverlays() {
        views.forEach { runCatching { wm?.removeView(it) } }
        views.clear()
    }

    // يُعاد بناء الشرائح كلما تغيّرت الإعدادات
    fun rebuild() {
        removeOverlays()
        val w = wm ?: return
        val dm = resources.displayMetrics
        val dp = dm.density
        val edgeAction = Prefs.getInt(this, "gEdge", GestureAction.BACK)
        val bottomAction = Prefs.getInt(this, "gBottom", GestureAction.NONE)
        val holdAction = Prefs.getInt(this, "gBottomHold", GestureAction.NONE)

        if (edgeAction != GestureAction.NONE) {
            // الحافتان تغطيان 55٪ من الارتفاع في الوسط حتى لا تعيقا لوحة المفاتيح والأزرار
            val h = (dm.heightPixels * 0.55f).toInt()
            add(w, Gravity.START or Gravity.CENTER_VERTICAL, (18 * dp).toInt(), h) { it.edge(+1f, edgeAction, dp) }
            add(w, Gravity.END or Gravity.CENTER_VERTICAL, (18 * dp).toInt(), h) { it.edge(-1f, edgeAction, dp) }
        }
        if (bottomAction != GestureAction.NONE || holdAction != GestureAction.NONE) {
            add(w, Gravity.BOTTOM, (dm.widthPixels * 0.6f).toInt(), (22 * dp).toInt()) {
                it.bottom(bottomAction, holdAction, dp)
            }
        }
    }

    private fun add(w: WindowManager, gravity: Int, width: Int, height: Int, setup: (View) -> Unit) {
        val v = View(this)
        setup(v)
        val lp = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = gravity
        runCatching { w.addView(v, lp); views.add(v) }
    }

    // سحب أفقي نحو داخل الشاشة => وظيفة الحافة
    private fun View.edge(dir: Float, action: Int, dp: Float) {
        var startX = 0f
        var done = false
        setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startX = e.rawX; done = false }
                MotionEvent.ACTION_MOVE -> if (!done && (e.rawX - startX) * dir > 56 * dp) {
                    done = true
                    run(action)
                }
            }
            true
        }
    }

    // سحب للأعلى من الأسفل: سريع => الوظيفة الأولى، مع التوقف => الثانية
    private fun View.bottom(quick: Int, hold: Int, dp: Float) {
        var startY = 0f
        var t0 = 0L
        setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startY = e.rawY; t0 = e.eventTime }
                MotionEvent.ACTION_UP -> if (startY - e.rawY > 70 * dp) {
                    val slow = e.eventTime - t0 > 450
                    run(if (slow) hold else quick)
                }
            }
            true
        }
    }

    private fun run(action: Int) {
        when (action) {
            GestureAction.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            GestureAction.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            GestureAction.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            GestureAction.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            GestureAction.LOCK ->
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    companion object {
        @Volatile var instance: GestureService? = null

        fun refresh() { instance?.rebuild() }

        fun isEnabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            return s.contains(c.packageName + "/")
        }

        // تنفيذ وظيفة من داخل الواجهة (مثل الضغطتين)
        fun perform(c: Context, action: Int) {
            if (action == GestureAction.NONE) return
            val svc = instance
            if (svc == null) {
                Toast.makeText(c, "فعّل خدمة الإيماءات من إعدادات الواجهة أولاً", Toast.LENGTH_SHORT).show()
                return
            }
            svc.run(action)
        }
    }
}
