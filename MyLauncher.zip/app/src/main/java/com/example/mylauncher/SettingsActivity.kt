package com.example.mylauncher

import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SettingsActivity : ComponentActivity() {
    // يزداد عند العودة من إعدادات النظام لتحديث حالة خدمة الإيماءات
    private var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { SettingsScreen(resumeTick) }
    }
}

@Composable
fun SettingsScreen(resumeTick: Int = 0) {
    val context = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var s by remember { mutableStateOf(Prefs.load(context)) }

    fun setInt(key: String, value: Int) {
        Prefs.putInt(context, key, value)
        s = Prefs.load(context)
    }

    fun setBool(key: String, value: Boolean) {
        Prefs.putBool(context, key, value)
        s = Prefs.load(context)
    }

    fun gSet(key: String, value: Int) {
        Prefs.putInt(context, key, value)
        GestureService.refresh()
        tick++
    }

    // يتغيّر عند أي تعديل أو عند العودة من إعدادات النظام لتحديث الحالات المعروضة
    val stamp = tick + resumeTick

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { tick++ }

    // طلب تعيين My Launcher كشاشة رئيسية: نافذة النظام المباشرة (أندرويد 10+) أو القائمة العامة
    fun requestHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = context.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                val ok = runCatching { roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME)) }
                if (ok.isSuccess) return
            }
        }
        openHomeChooser(context)
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(s.theme)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "إعدادات الواجهة",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Section("الواجهة الأساسية") {
                val isDefault = remember(stamp) { isDefaultHome(context) }
                Text(
                    text = if (isDefault) "My Launcher هو الشاشة الرئيسية الآن ✓"
                    else "My Launcher ليس الشاشة الرئيسية حالياً ✗",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 14.sp
                )
                Text(
                    "عندما يكون My Launcher هو الشاشة الرئيسية، يعيدك إغلاق أي تطبيق فتحتَه من هنا إليه مباشرة. " +
                        "واجهته مستقلة: شريطه السفلي وشاشته الرئيسية تختارهما أنت فقط.",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp
                )
                Setting(if (isDefault) "التبديل عند الحاجة" else "الإعداد") {
                    Chip(if (isDefault) "التبديل إلى واجهة أخرى" else "تعيين My Launcher كشاشة رئيسية", false) {
                        if (isDefault) openHomeChooser(context) else requestHome()
                    }
                }
            }

            Section("الأيقونات") {
                Setting("حجم الأيقونات") {
                    Chip("صغير", s.iconSize == 0) { setInt("iconSize", 0) }
                    Chip("متوسط", s.iconSize == 1) { setInt("iconSize", 1) }
                    Chip("كبير", s.iconSize == 2) { setInt("iconSize", 2) }
                }
                Setting("عدد الأعمدة في قائمة التطبيقات") {
                    Chip("4", s.columns == 4) { setInt("columns", 4) }
                    Chip("5", s.columns == 5) { setInt("columns", 5) }
                }
                Setting("إظهار أسماء التطبيقات") {
                    Chip("تشغيل", s.labels) { setBool("labels", true) }
                    Chip("إيقاف", !s.labels) { setBool("labels", false) }
                }
            }

            Section("الشاشة الرئيسية") {
                Setting("أقصى عدد لتطبيقات الشريط السفلي") {
                    Chip("3", s.dockCount == 3) { setInt("dockCount", 3) }
                    Chip("4", s.dockCount == 4) { setInt("dockCount", 4) }
                    Chip("5", s.dockCount == 5) { setInt("dockCount", 5) }
                }
                Setting("لون الخلفية") {
                    AuroraThemes.forEachIndexed { i, colors ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(colors))
                                .border(
                                    if (s.theme == i) 2.dp else 1.dp,
                                    Color.White.copy(alpha = if (s.theme == i) 0.95f else 0.3f),
                                    CircleShape
                                )
                                .tappable { setInt("theme", i) }
                        )
                    }
                }
            }

            Section("الإيماءات") {
                // قراءة tick و resumeTick تجعل هذا القسم يُحدَّث عند أي تغيير
                val gTick = tick + resumeTick
                val enabled = remember(gTick) { GestureService.isEnabled(context) }
                Text(
                    text = if (enabled) "الخدمة: مفعّلة ✓" else "الخدمة: غير مفعّلة",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp
                )
                Setting("تفعيل الخدمة") {
                    Chip("فتح إعدادات إمكانية الوصول", false) {
                        context.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                val edge = remember(gTick) { Prefs.getInt(context, "gEdge", GestureAction.BACK) }
                val bottom = remember(gTick) { Prefs.getInt(context, "gBottom", GestureAction.NONE) }
                val hold = remember(gTick) { Prefs.getInt(context, "gBottomHold", GestureAction.NONE) }
                val dbl = remember(gTick) { Prefs.getInt(context, "gDouble", GestureAction.NONE) }
                Setting("السحب من حافة الشاشة") {
                    Chip("بلا", edge == 0) { gSet("gEdge", 0) }
                    Chip("رجوع", edge == 1) { gSet("gEdge", 1) }
                    Chip("الرئيسية", edge == 2) { gSet("gEdge", 2) }
                    Chip("الأخيرة", edge == 3) { gSet("gEdge", 3) }
                }
                Setting("السحب للأعلى من أسفل الشاشة") {
                    Chip("بلا", bottom == 0) { gSet("gBottom", 0) }
                    Chip("الرئيسية", bottom == 2) { gSet("gBottom", 2) }
                    Chip("الأخيرة", bottom == 3) { gSet("gBottom", 3) }
                    Chip("رجوع", bottom == 1) { gSet("gBottom", 1) }
                }
                Setting("السحب للأعلى مع التوقف") {
                    Chip("بلا", hold == 0) { gSet("gBottomHold", 0) }
                    Chip("الأخيرة", hold == 3) { gSet("gBottomHold", 3) }
                    Chip("الرئيسية", hold == 2) { gSet("gBottomHold", 2) }
                    Chip("الإشعارات", hold == 4) { gSet("gBottomHold", 4) }
                }
                Setting("ضغطتان على الشاشة الرئيسية") {
                    Chip("بلا", dbl == 0) { gSet("gDouble", 0) }
                    Chip("قفل الشاشة", dbl == 5) { gSet("gDouble", 5) }
                    Chip("الإشعارات", dbl == 4) { gSet("gDouble", 4) }
                }
                Text(
                    "إيماءة الأسفل قد تتعارض مع إيماءات نظام الهاتف، فهي معطّلة افتراضياً.",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp
                )
            }

            Section("شاشة القفل") {
                val lockOn = remember(stamp) { Prefs.getInt(context, "lockOn", 0) }
                val lockPos = remember(stamp) { Prefs.getInt(context, "lockPos", 1) }
                val lockStyle = remember(stamp) { Prefs.getInt(context, "lockStyle", 0) }
                val lockSize = remember(stamp) { Prefs.getInt(context, "lockSize", 1) }
                val lockDate = remember(stamp) { Prefs.getInt(context, "lockDate", 1) }
                val svcOn = remember(stamp) { GestureService.isEnabled(context) }
                Text(
                    text = if (svcOn) "خدمة إمكانية الوصول: مفعّلة ✓" else "خدمة إمكانية الوصول: مطلوبة لتشغيل شاشة القفل تلقائياً",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 14.sp
                )
                Setting("تفعيل شاشة قفل My Launcher") {
                    Chip("تشغيل", lockOn == 1) { gSet("lockOn", 1) }
                    Chip("إيقاف", lockOn == 0) { gSet("lockOn", 0) }
                }
                Setting("الصلاحية المطلوبة") {
                    Chip("إعدادات إمكانية الوصول", false) {
                        context.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                Setting("موضع الساعة") {
                    Chip("أعلى", lockPos == 0) { gSet("lockPos", 0) }
                    Chip("وسط", lockPos == 1) { gSet("lockPos", 1) }
                    Chip("أسفل", lockPos == 2) { gSet("lockPos", 2) }
                }
                Setting("نمط الساعة") {
                    Chip("نحيف", lockStyle == 0) { gSet("lockStyle", 0) }
                    Chip("عريض", lockStyle == 1) { gSet("lockStyle", 1) }
                }
                Setting("حجم الساعة") {
                    Chip("صغير", lockSize == 0) { gSet("lockSize", 0) }
                    Chip("متوسط", lockSize == 1) { gSet("lockSize", 1) }
                    Chip("كبير", lockSize == 2) { gSet("lockSize", 2) }
                }
                Setting("التاريخ") {
                    Chip("إظهار", lockDate == 1) { gSet("lockDate", 1) }
                    Chip("إخفاء", lockDate == 0) { gSet("lockDate", 0) }
                }
                Setting("معاينة بدون قفل الهاتف") {
                    Chip("معاينة الآن", false) {
                        context.startActivity(
                            Intent(context, LockActivity::class.java).putExtra("preview", true)
                        )
                    }
                }
                Text(
                    "تحتاج الخدمة إلى تفعيل «إيماءات My Launcher» من إمكانية الوصول حتى تتمكن من إظهار الشاشة عند تشغيل الهاتف. لا تحتاج صلاحية الظهور فوق التطبيقات. هذه طبقة مرئية فوق قفل أندرويد وليست بديلاً أمنياً عنه؛ البصمة والوجه والنمط والرقم السري تبقى تحت تحكم النظام.",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp
                )
            }

            Section("النظام") {
                Text("الإصدار 0.8", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
            }

            Text(
                text = "تظهر التغييرات عند العودة إلى الشاشة الرئيسية.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp
            )
        }
    }
}

// بطاقة زجاجية تجمع عدة إعدادات
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .plate(RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        content()
    }
}

// سطر إعداد: عنوان + خيارات
@Composable
fun Setting(label: String, content: @Composable RowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, color = Color.White, fontSize = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { content() }
    }
}

// زر خيار زجاجي صغير
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .clip(shape)
            .background(Color.White.copy(alpha = if (selected) 0.30f else 0.08f))
            .border(1.dp, Color.White.copy(alpha = if (selected) 0.75f else 0.2f), shape)
            .tappable(onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}
