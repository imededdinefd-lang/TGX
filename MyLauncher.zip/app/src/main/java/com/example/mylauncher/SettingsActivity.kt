package com.example.mylauncher

import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

class SettingsActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { SettingsScreen(resumeTick) }
    }
}

private data class SettingsGroup(val title: String, val subtitle: String, val keywords: String)

@Composable
fun SettingsScreen(resumeTick: Int = 0) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val data by SettingsStore.values(context).collectAsState(initial = emptyMap())
    var query by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val current = Prefs.load(context)
    val stateVersion = refresh + resumeTick
    fun int(key: String, fallback: Int) = (data[key] as? Int) ?: Prefs.getInt(context, key, fallback)
    fun bool(key: String, fallback: Boolean) = (data[key] as? Boolean) ?: fallback
    fun writeInt(key: String, value: Int, gesture: Boolean = false) {
        Prefs.putInt(context, key, value)
        scope.launch { SettingsStore.putInt(context, key, value) }
        if (gesture) GestureService.refresh()
        refresh++
    }
    fun writeBool(key: String, value: Boolean) {
        Prefs.putBool(context, key, value)
        scope.launch { SettingsStore.putBoolean(context, key, value) }
        refresh++
    }

    val groups = listOf(
        SettingsGroup("المظهر والتخصيص", "الثيم والألوان والشفافية", "appearance theme dark amoled light auto accent color glass transparency preview"),
        SettingsGroup("الأيقونات والشاشة الرئيسية", "الأحجام والشبكة وأسماء التطبيقات", "icons size grid columns labels home dock"),
        SettingsGroup("استوديو شاشة القفل", "الساعة والمعاينة وطريقة العرض", "lock screen clock style position date preview shortcut"),
        SettingsGroup("التنقل والإيماءات", "حركات السحب والاستجابة", "navigation gestures swipe edge double tap haptic animation"),
        SettingsGroup("لوحة التحكم والتطبيقات الأخيرة", "إعدادات التجربة متعددة المهام", "control panel quick settings recents stacked cards"),
        SettingsGroup("العزل وإدارة التطبيقات", "استقلال الواجهة والتطبيقات", "isolation hidden apps folders reset app manager"),
        SettingsGroup("الأداء والنسخ الاحتياطي", "الأداء وحفظ إعداداتك", "performance fps backup restore diagnostics"),
        SettingsGroup("سلامة الصلاحيات", "حالة تكامل My Launcher مع أندرويد", "permissions health home overlay accessibility restricted settings")
    )
    val filtered = groups.filter { query.isBlank() || (it.title + " " + it.subtitle + " " + it.keywords).contains(query.trim(), true) }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            val json = JSONObject()
            data.forEach { (k, v) -> json.put(k, v) }
            // Include legacy synchronous preferences (home/dock order and gesture/lock values).
            context.getSharedPreferences("launcher", android.content.Context.MODE_PRIVATE).all.forEach { (k, v) ->
                if (v is String || v is Boolean || v is Number) json.put(k, v)
            }
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(json.toString(2).toByteArray()) } }
        }
    }
    val restoreBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching {
            val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "{}"
            val obj = JSONObject(json)
            obj.keys().forEach { key ->
                when (val value = obj.get(key)) {
                    is Boolean -> writeBool(key, value)
                    is Number -> writeInt(key, value.toInt(), key.startsWith("g") || key.startsWith("lock"))
                    is String -> {
                        context.getSharedPreferences("launcher", android.content.Context.MODE_PRIVATE).edit().putString(key, value).apply()
                        scope.launch { SettingsStore.putString(context, key, value) }
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(current.theme)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("MY LAUNCHER", color = Color(0xFFB9A8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("الإعدادات", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                    Text("مساحة التحكم والتخصيص · $stateVersion", color = Color.White.copy(alpha = .58f), fontSize = 13.sp)
                }
                Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = .10f)).border(1.dp, Color.White.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 23.sp)
                }
            }

            // Instant search over setting groups and their searchable options.
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .10f))
                .border(1.dp, Color.White.copy(alpha = .15f), RoundedCornerShape(18.dp)).padding(horizontal = 15.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("⌕", color = Color.White.copy(alpha = .7f), fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                    decorationBox = { inner -> Box { if (query.isEmpty()) Text("ابحث عن أي إعداد…", color = Color.White.copy(alpha = .42f), fontSize = 14.sp); inner() } },
                    modifier = Modifier.weight(1f))
                if (query.isNotEmpty()) Text("مسح", color = Color(0xFFC7B8FF), modifier = Modifier.clickable { query = "" }.padding(4.dp))
            }

            // Live preview card: values are read from the same state used by the controls below.
            if (query.isBlank() || "معاينة preview المظهر theme الأيقونات icons شاشة القفل lock".contains(query, true)) {
                GlassPanel {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("معاينة مباشرة", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("LIVE", color = Color(0xFF8BE7D2), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("◉", "✉", "◎", "▣").forEachIndexed { i, glyph ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(Modifier.size((48 + current.iconSize * 5).dp).clip(RoundedCornerShape(16.dp))
                                    .background(AuroraThemes[current.theme.coerceIn(0, AuroraThemes.lastIndex)][i % 3].copy(alpha = .25f))
                                    .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                    Text(glyph, color = Color.White, fontSize = 23.sp)
                                }
                                if (current.labels) Text(listOf("تطبيق", "رسائل", "صور", "ملفات")[i], color = Color.White.copy(alpha = .7f), fontSize = 10.sp)
                            }
                        }
                    }
                    Text("تتغير المعاينة مع خيارات الحجم والثيم والأسماء.", color = Color.White.copy(alpha = .48f), fontSize = 11.sp)
                }
            }

            if (filtered.isEmpty()) {
                GlassPanel { Text("لا توجد نتائج مطابقة", color = Color.White, fontSize = 15.sp); Text("جرّب كلمة أخرى مثل: الأيقونات، الساعة، الإيماءات.", color = Color.White.copy(alpha = .55f), fontSize = 12.sp) }
            }

            if (filtered.any { it.title == "المظهر والتخصيص" }) GlassSection("✦", "المظهر والتخصيص", "الثيم، الألوان، والمواد الزجاجية") {
                SettingLine("نمط الواجهة", "الاختيار الفعّال حالياً هو الثيم اللوني") {
                    Choice("Aurora", current.theme == 0) { writeInt("theme", 0) }
                    Choice("Ocean", current.theme == 1) { writeInt("theme", 1) }
                    Choice("Sunset", current.theme == 2) { writeInt("theme", 2) }
                    Choice("Graphite", current.theme == 3) { writeInt("theme", 3) }
                }
                SettingLine("تفضيل شفافية الزجاج", "يُحفظ الآن؛ ربطه بمحرك البطاقات ضمن مرحلة المظهر") {
                    Choice("خفيف", int("glassAlpha", 35) == 35) { writeInt("glassAlpha", 35) }
                    Choice("متوسط", int("glassAlpha", 35) == 60) { writeInt("glassAlpha", 60) }
                    Choice("قوي", int("glassAlpha", 35) == 85) { writeInt("glassAlpha", 85) }
                }
                SettingLine("لون التمييز", "ألوان الواجهة") {
                    listOf(0xFF9A82FF, 0xFF62D8C6, 0xFFFFA66D, 0xFF83B8FF).forEachIndexed { i, c ->
                        Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).border(if (int("accentColor", 0) == i) 3.dp else 1.dp, Color.White.copy(alpha = .7f), CircleShape).clickable { writeInt("accentColor", i) })
                    }
                }
                Text("الثيمات AMOLED / الفاتح / التلقائي واستخراج Monet من الخلفية تحتاج ربطاً إضافياً بمحرك الألوان قبل تفعيلها فعلياً.", color = Color(0xFFFFD28A), fontSize = 11.sp)
            }

            if (filtered.any { it.title == "الأيقونات والشاشة الرئيسية" }) GlassSection("▦", "الأيقونات والشاشة الرئيسية", "حجم العرض وتخطيط الشبكة") {
                SettingLine("حجم الأيقونات", "يُطبّق على درج التطبيقات") {
                    Choice("صغير", current.iconSize == 0) { writeInt("iconSize", 0) }
                    Choice("متوسط", current.iconSize == 1) { writeInt("iconSize", 1) }
                    Choice("كبير", current.iconSize == 2) { writeInt("iconSize", 2) }
                }
                SettingLine("أعمدة الدرج", "عدد العناصر في كل صف") {
                    Choice("4", current.columns == 4) { writeInt("columns", 4) }
                    Choice("5", current.columns == 5) { writeInt("columns", 5) }
                }
                SettingLine("أسماء التطبيقات", "إظهار أو إخفاء التسميات") {
                    Choice("إظهار", current.labels) { writeBool("labels", true) }
                    Choice("إخفاء", !current.labels) { writeBool("labels", false) }
                }
                SettingLine("عناصر الشريط السفلي", "الحد الأقصى للعناصر") {
                    listOf(3,4,5).forEach { Choice(it.toString(), current.dockCount == it) { writeInt("dockCount", it) } }
                }
            }

            if (filtered.any { it.title == "استوديو شاشة القفل" }) GlassSection("◷", "استوديو شاشة القفل", "تخصيص الساعة ومعاينة النتيجة") {
                val enabled = GestureService.isEnabled(context)
                StatusLine("خدمة إمكانية الوصول", if (enabled) "مفعّلة" else "غير مفعّلة", enabled)
                SettingLine("تشغيل شاشة القفل", "تفعيل العرض عبر خدمة الإيماءات") {
                    Choice("تشغيل", int("lockOn", 0) == 1) { writeInt("lockOn", 1, true) }
                    Choice("إيقاف", int("lockOn", 0) == 0) { writeInt("lockOn", 0, true) }
                }
                SettingLine("موضع الساعة", "مكان ظهور الساعة") {
                    listOf("أعلى", "وسط", "أسفل").forEachIndexed { i, t -> Choice(t, int("lockPos", 1) == i) { writeInt("lockPos", i, true) } }
                }
                SettingLine("نمط الساعة", "وزن الخط") {
                    Choice("كلاسيكي", int("lockStyle", 0) == 0) { writeInt("lockStyle", 0, true) }
                    Choice("عريض", int("lockStyle", 0) == 1) { writeInt("lockStyle", 1, true) }
                }
                SettingLine("حجم الساعة", "حجم النص") {
                    listOf("صغير", "متوسط", "كبير").forEachIndexed { i, t -> Choice(t, int("lockSize", 1) == i) { writeInt("lockSize", i, true) } }
                }
                SettingLine("التاريخ", "إظهار التاريخ على شاشة القفل") {
                    Choice("إظهار", int("lockDate", 1) == 1) { writeInt("lockDate", 1, true) }
                    Choice("إخفاء", int("lockDate", 1) == 0) { writeInt("lockDate", 0, true) }
                }
                ActionPill("معاينة شاشة القفل الآن") { context.startActivity(Intent(context, LockActivity::class.java).putExtra("preview", true)) }
                ActionPill("فتح إعدادات إمكانية الوصول") { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                Text("النص المخصص والاختصارات وأنماط الساعة العمودية والخطوط الإضافية لم تُربط بعد بمحرك شاشة القفل.", color = Color(0xFFFFD28A), fontSize = 11.sp)
            }

            if (filtered.any { it.title == "التنقل والإيماءات" }) GlassSection("⌁", "التنقل والإيماءات", "اختصارات السحب وسلوك اللمس") {
                StatusLine("خدمة الإيماءات", if (GestureService.isEnabled(context)) "مفعّلة" else "تحتاج تفعيل" , GestureService.isEnabled(context))
                GestureChoice("السحب من الحافة", "gEdge", listOf("بلا" to 0, "رجوع" to 1, "الرئيسية" to 2, "الأخيرة" to 3), ::writeInt)
                GestureChoice("السحب للأعلى", "gBottom", listOf("بلا" to 0, "رجوع" to 1, "الرئيسية" to 2, "الأخيرة" to 3), ::writeInt)
                GestureChoice("السحب مع التوقف", "gBottomHold", listOf("بلا" to 0, "الرئيسية" to 2, "الأخيرة" to 3, "الإشعارات" to 4), ::writeInt)
                GestureChoice("النقر المزدوج", "gDouble", listOf("بلا" to 0, "الإشعارات" to 4, "قفل الشاشة" to 5), ::writeInt)
                ActionPill("إدارة خدمة الإيماءات") { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                Text("حساسية الحواف والاهتزاز وسرعة الحركة ليست موصولة بعد بمحرّك الإيماءات.", color = Color(0xFFFFD28A), fontSize = 11.sp)
            }

            if (filtered.any { it.title == "لوحة التحكم والتطبيقات الأخيرة" }) GlassSection("▤", "لوحة التحكم والتطبيقات الأخيرة", "ميزات الواجهة المتقدمة") {
                StatusLine("لوحة تحكم سريعة مستقلة", "قيد التطوير", false)
                StatusLine("عرض التطبيقات الأخيرة المكدّس", "قيد التطوير", false)
                Text("ستُضاف عناصر التحكم السريع ونمط Stacked Cards عند تنفيذ شاشتي لوحة التحكم والتطبيقات الأخيرة، ولن تظهر كمفاتيح شكلية غير فعّالة.", color = Color.White.copy(alpha = .58f), fontSize = 12.sp)
            }

            if (filtered.any { it.title == "العزل وإدارة التطبيقات" }) GlassSection("◈", "العزل وإدارة التطبيقات", "مصدر التطبيقات وعناصر الواجهة") {
                StatusLine("الشاشة الرئيسية المستقلة", "مفعّلة", true)
                StatusLine("إضافة التطبيقات يدوياً", "مدعومة", true)
                StatusLine("وضع العزل التام", "قيد التنفيذ", false)
                Text("الشاشة الرئيسية والشريط السفلي مستقلان حالياً. مرشح التطبيقات الذي يعرض التطبيقات المختارة فقط، ومدير التطبيقات المخفية والمجلدات وتحرير الأيقونات، ستُنفّذ في المرحلة التالية.", color = Color(0xFFFFD28A), fontSize = 11.sp)
            }

            if (filtered.any { it.title == "الأداء والنسخ الاحتياطي" }) GlassSection("⇧", "الأداء والنسخ الاحتياطي", "حفظ إعداداتك وفحص الأداء") {
                SettingLine("تفضيل معدل الإطارات", "حفظ التفضيل؛ ربطه بمحرك الحركة لاحقاً") {
                    listOf("60", "90", "120").forEachIndexed { i, t -> Choice(t, int("targetFps", 0) == i) { writeInt("targetFps", i) } }
                }
                SettingLine("تقليل التأثيرات", "تقليل الزخارف لتخفيف الحمل") {
                    Choice("تشغيل", bool("reduceEffects", false)) { writeBool("reduceEffects", true) }
                    Choice("إيقاف", !bool("reduceEffects", false)) { writeBool("reduceEffects", false) }
                }
                ActionPill("تصدير نسخة احتياطية") { createBackup.launch("my-launcher-backup.json") }
                ActionPill("استيراد نسخة احتياطية") { restoreBackup.launch(arrayOf("application/json", "text/*")) }
                Text("اختيار 90/120 إطاراً هو تفضيل فقط؛ الحد الفعلي تحدده الشاشة والنظام. تقليل التأثيرات يحتاج ربطاً ببقية مكوّنات الحركة.", color = Color.White.copy(alpha = .55f), fontSize = 11.sp)
            }

            if (filtered.any { it.title == "سلامة الصلاحيات" }) GlassSection("✓", "سلامة الصلاحيات", "حالة متطلبات النظام") {
                val isHome = isDefaultHome(context)
                val access = GestureService.isEnabled(context)
                val overlay = if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(context) else true
                StatusLine("تعيين الشاشة الرئيسية", if (isHome) "مفعّل" else "غير معيّن", isHome)
                ActionPill(if (isHome) "تبديل الشاشة الرئيسية" else "تعيين My Launcher كشاشة رئيسية") {
                    if (isHome) openHomeChooser(context) else {
                        if (Build.VERSION.SDK_INT >= 29) {
                            val rm = context.getSystemService(RoleManager::class.java)
                            if (rm?.isRoleAvailable(RoleManager.ROLE_HOME) == true) context.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME)) else openHomeChooser(context)
                        } else openHomeChooser(context)
                    }
                }
                StatusLine("إمكانية الوصول", if (access) "مفعّلة" else "غير مفعّلة", access)
                ActionPill("فتح إعدادات إمكانية الوصول") { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                StatusLine("الظهور فوق التطبيقات", if (overlay) "مسموح" else "غير مسموح", overlay)
                if (Build.VERSION.SDK_INT >= 23) ActionPill("إعداد الظهور فوق التطبيقات") { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }
                Text("قد تمنع بعض الشركات المصنّعة تفعيل خدمات الوصول من شاشة الإعدادات المحظورة/المقيّدة. إذا ظهر هذا التنبيه، افتح معلومات التطبيق ثم اسمح بالإعدادات المحظورة يدوياً. لا نطلب صلاحية غير مستخدمة.", color = Color.White.copy(alpha = .58f), fontSize = 11.sp)
            }

            Text("My Launcher · Settings Studio · 0.9.0", color = Color.White.copy(alpha = .35f), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp))
        }
    }
}

@Composable private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .13f), Color.White.copy(alpha = .055f))))
        .border(1.dp, Color.White.copy(alpha = .16f), RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}
@Composable private fun GlassSection(symbol: String, title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp)).background(Color(0xD91A1A29)).border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(23.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF8D79FF).copy(alpha = .22f)), contentAlignment = Alignment.Center) { Text(symbol, color = Color(0xFFD4C9FF), fontSize = 20.sp) }
            Column { Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.White.copy(alpha = .48f), fontSize = 11.sp) }
        }
        content()
    }
}
@Composable private fun SettingLine(title: String, subtitle: String, content: @Composable RowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium); Text(subtitle, color = Color.White.copy(alpha = .45f), fontSize = 10.sp) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}
@Composable private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(Modifier.clip(shape).background(if (selected) Color(0xFF8D79FF).copy(alpha = .32f) else Color.White.copy(alpha = .065f))
        .border(1.dp, if (selected) Color(0xFFBBAEFF).copy(alpha = .65f) else Color.White.copy(alpha = .10f), shape)
        .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (selected) Color.White else Color.White.copy(alpha = .68f), fontSize = 11.sp)
    }
}
@Composable private fun StatusLine(label: String, status: String, good: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White.copy(alpha = .78f), fontSize = 12.sp)
        Text(status, color = if (good) Color(0xFF8BE7C5) else Color(0xFFFFC47D), fontSize = 11.sp)
    }
}
@Composable private fun ActionPill(label: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .085f)).border(1.dp, Color.White.copy(alpha = .13f), RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(13.dp)) {
        Text(label, color = Color(0xFFD8D0FF), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
@Composable private fun GestureChoice(title: String, key: String, options: List<Pair<String, Int>>, setter: (String, Int, Boolean) -> Unit) {
    val context = LocalContext.current
    val value = Prefs.getInt(context, key, 0)
    SettingLine(title, "تعيين سلوك الإيماءة") { options.forEach { (label, id) -> Choice(label, value == id) { setter(key, id, true) } } }
}
