package com.example.mylauncher

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SettingsHome() }
    }
}

@Composable
private fun SettingsHome() {
    val context = LocalContext.current
    var settings by remember { mutableStateOf(Prefs.load(context)) }
    var defaultLauncher by remember { mutableStateOf(isDefaultLauncher(context)) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        defaultLauncher = isDefaultLauncher(context)
    }
    val bg = Prefs.background(settings.theme)
    val accent = Prefs.accent(settings.theme)

    fun update(transform: (LauncherSettings) -> LauncherSettings) {
        Prefs.update(context, transform)
        settings = Prefs.load(context)
    }

    Column(
        Modifier.fillMaxSize().background(bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp).padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("إعدادات My Launcher", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("إعدادات أساسية، مباشرة ومحفوظة تلقائياً", color = Color.White.copy(alpha = .62f), fontSize = 13.sp)

        SettingsCard {
            Text("تعيين الشاشة الرئيسية", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(if (defaultLauncher) "My Launcher هو اللانشر الافتراضي حالياً" else "اختر My Launcher كتطبيق الشاشة الرئيسية الافتراضي",
                color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
            ActionPill(if (defaultLauncher) "تم التعيين" else "تعيين My Launcher", accent) {
                val roleManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) context.getSystemService(RoleManager::class.java) else null
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
                } else {
                    runCatching { context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        .onFailure { context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            }
        }

        SettingsCard {
            Text("المظهر والألوان", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("اختر لون الواجهة", color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf(0, 1, 2, 3).forEach { theme ->
                    val color = Prefs.accent(theme)
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                        .background(color).clickable { update { it.copy(theme = theme) } }) {
                        if (settings.theme == theme) Text("✓", Modifier.align(Alignment.Center), color = Color(0xFF101116), fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("شفافية الزجاج", color = Color.White, modifier = Modifier.weight(1f))
                Text("${settings.glassAlpha}%", color = accent, fontSize = 13.sp)
            }
            Slider(value = settings.glassAlpha.toFloat(), onValueChange = { value -> update { it.copy(glassAlpha = value.toInt()) } }, valueRange = 0f..40f)
        }

        SettingsCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("حجم الأيقونات", color = Color.White, modifier = Modifier.weight(1f))
                Text("${settings.iconSize} dp", color = accent, fontSize = 13.sp)
            }
            Slider(value = settings.iconSize.toFloat(), onValueChange = { value -> update { it.copy(iconSize = value.toInt()) } }, valueRange = 48f..76f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("أعمدة درج التطبيقات", color = Color.White, modifier = Modifier.weight(1f))
                Text("${settings.columns}", color = accent, fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (3..6).forEach { count ->
                    val selected = settings.columns == count
                    Box(Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (selected) accent else Color.White.copy(alpha = .08f))
                        .clickable { update { it.copy(columns = count) } }, contentAlignment = Alignment.Center) {
                        Text(count.toString(), color = if (selected) Color(0xFF101116) else Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Text("تُحفظ التغييرات فوراً على هذا الجهاز.", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Color.White.copy(alpha = .075f)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable
private fun ActionPill(label: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(14.dp)).background(color).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(label, color = Color(0xFF101116), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

private fun isDefaultLauncher(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val roleManager = context.getSystemService(RoleManager::class.java)
        roleManager?.isRoleHeld(RoleManager.ROLE_HOME) == true
    } else {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        context.packageManager.resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName == context.packageName
    }
}
