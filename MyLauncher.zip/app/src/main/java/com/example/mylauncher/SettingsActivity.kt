package com.example.mylauncher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { SettingsScreen() }
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    var s by remember { mutableStateOf(Prefs.load(context)) }

    fun setInt(key: String, value: Int) {
        Prefs.putInt(context, key, value)
        s = Prefs.load(context)
    }

    fun setBool(key: String, value: Boolean) {
        Prefs.putBool(context, key, value)
        s = Prefs.load(context)
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(s.theme)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "إعدادات الواجهة",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Section("الأيقونات") {
                Setting("حجم الأيقونات") {
                    Chip("صغير", s.iconSize == 0) { setInt("iconSize", 0) }
                    Chip("متوسط", s.iconSize == 1) { setInt("iconSize", 1) }
                    Chip("كبير", s.iconSize == 2) { setInt("iconSize", 2) }
                }
                Setting("عدد الأعمدة في قائمة التطبيقات") {
                    Chip("4", s.columns == 4) { setInt("columns", 4) }
                    Chip("5", s.columns == 5) { setInt("columns", 5) }
                }
                Setting("إظهار أسماء التطبيقات") {
                    Chip("تشغيل", s.labels) { setBool("labels", true) }
                    Chip("إيقاف", !s.labels) { setBool("labels", false) }
                }
            }

            Section("الشاشة الرئيسية") {
                Setting("عدد تطبيقات الشريط السفلي") {
                    Chip("3", s.dockCount == 3) { setInt("dockCount", 3) }
                    Chip("4", s.dockCount == 4) { setInt("dockCount", 4) }
                    Chip("5", s.dockCount == 5) { setInt("dockCount", 5) }
                }
                Setting("لون الخلفية") {
                    AuroraThemes.forEachIndexed { i, colors ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(colors))
                                .border(
                                    if (s.theme == i) 2.dp else 1.dp,
                                    Color.White.copy(alpha = if (s.theme == i) 0.95f else 0.3f),
                                    CircleShape
                                )
                                .tappable { setInt("theme", i) }
                        )
                    }
                }
            }

            Section("النظام") {
                Setting("الشاشة الرئيسية الافتراضية") {
                    Chip("تغيير", false) {
                        openHomeChooser(context)
                    }
                }
                Text("الإصدار 0.3.1",color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
            }

            Text(
                text = "تظهر التغييرات عند العودة إلى الشاشة الرئيسية.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp
            )
        }
    }
}

// بطاقة زجاجية تجمع عدة إعدادات
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        content()
    }
}

// سطر إعداد: عنوان + خيارات
@Composable
fun Setting(label: String, content: @Composable RowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, color = Color.White, fontSize = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

// زر خيار زجاجي صغير
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .clip(shape)
            .background(Color.White.copy(alpha = if (selected) 0.30f else 0.08f))
            .border(1.dp, Color.White.copy(alpha = if (selected) 0.75f else 0.2f), shape)
            .tappable(onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}
