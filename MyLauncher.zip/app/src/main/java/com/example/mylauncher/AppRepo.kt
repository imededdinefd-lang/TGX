package com.example.mylauncher

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

// مخزن قائمة التطبيقات: يعيش مع العملية لا مع الواجهة، فتبقى القائمة جاهزة
// حتى لو أُعيد إنشاء النشاط، ويبدأ التحميل في الخلفية من أول لحظة.
object AppRepo {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val running = AtomicBoolean(false)
    @Volatile private var again = false

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    fun refresh(context: Context) {
        val app = context.applicationContext
        // إن كان تحميل جارياً نطلب جولة أخرى بعده بدل تشغيل جولتين معاً
        if (!running.compareAndSet(false, true)) {
            again = true
            return
        }
        scope.launch {
            try {
                do {
                    again = false
                    val list = loadApps(app, app.packageManager)
                    // لا نبدّل الحالة إن لم يتغير شيء، فلا تُعاد تركيبة الواجهة دون داعٍ
                    if (list != _apps.value) _apps.value = list
                } while (again)
            } finally {
                running.set(false)
            }
        }
    }
}
