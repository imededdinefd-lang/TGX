package com.example.mylauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

@androidx.compose.runtime.Immutable
data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: ImageBitmap
)

/** Bounded icon cache. Drawable decoding and package enumeration never run on the main thread. */
object AppRepo {
    private const val ICON_PX = 144
    private val cache = object : LruCache<String, Bitmap>(8 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    suspend fun load(context: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ownPackage = context.packageName
        pm.queryIntentActivities(query, 0)
            .asSequence()
            .map { it.activityInfo }
            .filter { info ->
                // The launcher itself is not shown as an app tile; its dedicated Settings entry is.
                !(info.packageName == ownPackage && info.name.endsWith(".MainActivity"))
            }
            .distinctBy { "${it.packageName}/${it.name}" }
            .mapNotNull { info ->
                runCatching {
                    val component = ComponentName(info.packageName, info.name)
                    val key = "${component.flattenToShortString()}#${info.applicationInfo.lastUpdateTime}"
                    val bitmap = synchronized(cache) { cache.get(key) } ?: run {
                        val drawable = info.loadIcon(pm)
                        val created = drawableToBitmap(drawable)
                        synchronized(cache) { cache.put(key, created) }
                        created
                    }
                    AppInfo(info.loadLabel(pm).toString(), component, bitmap.asImageBitmap())
                }.getOrNull()
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        val bitmap = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val old = Rect(drawable.bounds)
        val iw = drawable.intrinsicWidth.takeIf { it > 0 } ?: ICON_PX
        val ih = drawable.intrinsicHeight.takeIf { it > 0 } ?: ICON_PX
        val scale = minOf(ICON_PX.toFloat() / iw, ICON_PX.toFloat() / ih)
        val w = (iw * scale).toInt().coerceAtLeast(1)
        val h = (ih * scale).toInt().coerceAtLeast(1)
        val left = (ICON_PX - w) / 2
        val top = (ICON_PX - h) / 2
        drawable.setBounds(left, top, left + w, top + h)
        drawable.draw(canvas)
        drawable.bounds = old
        return bitmap
    }
}
