package com.example.mylauncher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

// فُرش ثابتة تُنشأ مرة واحدة بدل إنشائها مع كل تركيب
private val GlassFillFull = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.07f))
)
private val GlassBorder = Brush.linearGradient(
    listOf(
        Color.White.copy(alpha = 0.60f),
        Color.White.copy(alpha = 0.06f),
        Color.White.copy(alpha = 0.28f)
    )
)

// طابع زجاجي: تعبئة شفافة متدرجة + حد لامع + ظل ناعم اختياري
fun Modifier.glass(shape: Shape, strength: Float = 1f, shadowed: Boolean = true): Modifier = this
    .then(
        if (shadowed) Modifier.shadow(
            elevation = 10.dp,
            shape = shape,
            ambientColor = Color.Black.copy(alpha = 0.35f),
            spotColor = Color.Black.copy(alpha = 0.45f)
        ) else Modifier
    )
    .clip(shape)
    .background(
        if (strength == 1f) GlassFillFull
        else Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.22f * strength),
                Color.White.copy(alpha = 0.07f * strength)
            )
        )
    )
    .border(1.dp, GlassBorder, shape)

// نقرة بدون أثر مموّج
@Composable
fun Modifier.tappable(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = onClick
)

// ألوان الخلفية المتاحة (ثلاث بقع ضوئية لكل لون)
val AuroraThemes: List<List<Color>> = listOf(
    listOf(Color(0xFF6C4DFF), Color(0xFF00B8D9), Color(0xFFFF4D8D)),   // بنفسجي
    listOf(Color(0xFF2979FF), Color(0xFF00E5B0), Color(0xFF00B8D9)),   // محيط
    listOf(Color(0xFFFF7A18), Color(0xFFFF3D71), Color(0xFF7B2FF7)),   // غروب
    listOf(Color(0xFF8A94A6), Color(0xFF3D4A66), Color(0xFF5B6272))    // رمادي
)

private class Blob(val brush: Brush, val center: Offset, val radius: Float)

// خلفية داكنة بتوهجات ملونة. تُرسم مرة واحدة وتُخزَّن (drawWithCache) لتخفيف الحمل
@Composable
fun AuroraBackground(theme: Int) {
    val colors = AuroraThemes[theme.coerceIn(0, AuroraThemes.lastIndex)]
    Box(
        Modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val specs = listOf(
                    Triple(Offset(w * 0.10f, h * 0.15f), w * 1.0f, colors[0].copy(alpha = 0.55f)),
                    Triple(Offset(w * 0.95f, h * 0.45f), w * 0.9f, colors[1].copy(alpha = 0.40f)),
                    Triple(Offset(w * 0.30f, h * 0.95f), w * 1.0f, colors[2].copy(alpha = 0.30f))
                )
                val blobs = specs.map { (c, r, col) ->
                    Blob(Brush.radialGradient(listOf(col, Color.Transparent), center = c, radius = r), c, r)
                }
                onDrawBehind {
                    drawRect(Color(0xFF07070D))
                    for (b in blobs) {
                        drawCircle(brush = b.brush, radius = b.radius, center = b.center)
                    }
                }
            }
    )
}

// أيقونة العدسة المكبرة (مرسومة بالكود)
@Composable
fun SearchGlyph() {
    Canvas(Modifier.size(20.dp)) {
        val w = 2.dp.toPx()
        val c = Color.White.copy(alpha = 0.8f)
        drawCircle(
            color = c,
            radius = size.width * 0.32f,
            center = Offset(size.width * 0.42f, size.height * 0.42f),
            style = Stroke(width = w)
        )
        drawLine(
            color = c,
            start = Offset(size.width * 0.66f, size.height * 0.66f),
            end = Offset(size.width * 0.92f, size.height * 0.92f),
            strokeWidth = w,
            cap = StrokeCap.Round
        )
    }
}

// يفتح شاشة اختيار الشاشة الرئيسية الافتراضية، وإن لم تتوفر يجرّب شاشات أعم
fun openHomeChooser(context: Context) {
    val actions = listOf(
        Settings.ACTION_HOME_SETTINGS,
        Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,
        Settings.ACTION_SETTINGS
    )
    for (action in actions) {
        try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
            // نجرّب الخيار التالي
        }
    }
}
