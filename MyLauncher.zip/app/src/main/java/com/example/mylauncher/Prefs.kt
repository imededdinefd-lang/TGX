package com.example.mylauncher

import android.content.Context

// إعدادات الواجهة (تُحفظ على الهاتف وتُقرأ في الشاشة الرئيسية)
data class LauncherSettings(
    val iconSize: Int,     // 0 صغير، 1 متوسط، 2 كبير
    val columns: Int,      // عدد أعمدة قائمة التطبيقات (4 أو 5)
    val labels: Boolean,   // إظهار أسماء التطبيقات
    val theme: Int,        // رقم لون الخلفية
    val dockCount: Int     // عدد تطبيقات الشريط السفلي (3 إلى 5)
) {
    // حجم لوح الأيقونة بوحدة dp
    val tileDp: Int
        get() {
            val base = when (iconSize) {
                0 -> 54
                2 -> 68
                else -> 60
            }
            return if (columns >= 5) minOf(base, 58) else base
        }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun load(c: Context): LauncherSettings {
        val p = sp(c)
        return LauncherSettings(
            iconSize = p.getInt("iconSize", 1),
            columns = p.getInt("columns", 4),
            labels = p.getBoolean("labels", true),
            theme = p.getInt("theme", 0),
            dockCount = p.getInt("dockCount", 4)
        )
    }

    fun putInt(c: Context, key: String, value: Int) {
        sp(c).edit().putInt(key, value).apply()
    }

    fun putBool(c: Context, key: String, value: Boolean) {
        sp(c).edit().putBoolean(key, value).apply()
    }

    // تطبيقات الشاشة الرئيسية: أسماء الحزم بالترتيب
    fun loadHome(c: Context): List<String> {
        val s = sp(c).getString("home", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun saveHome(c: Context, list: List<String>) {
        sp(c).edit().putString("home", list.joinToString("\n")).apply()
    }
}
