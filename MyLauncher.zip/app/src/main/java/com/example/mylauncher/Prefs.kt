package com.example.mylauncher

import android.content.Context
import androidx.compose.ui.graphics.Color

/** Small, synchronous settings store. apply() persists asynchronously without blocking UI. */
data class LauncherSettings(
    val iconSize: Int = 60,
    val columns: Int = 4,
    val theme: Int = 0,
    val glassAlpha: Int = 18
)

object Prefs {
    private const val FILE = "my_launcher_preferences"
    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(context: Context) = prefs(context).let { p ->
        LauncherSettings(
            iconSize = p.getInt("icon_size", 60).coerceIn(48, 76),
            columns = p.getInt("columns", 4).coerceIn(3, 6),
            theme = p.getInt("theme", 0).coerceIn(0, 3),
            glassAlpha = p.getInt("glass_alpha", 18).coerceIn(0, 40)
        )
    }

    fun update(context: Context, transform: (LauncherSettings) -> LauncherSettings) {
        val next = transform(load(context))
        prefs(context).edit()
            .putInt("icon_size", next.iconSize.coerceIn(48, 76))
            .putInt("columns", next.columns.coerceIn(3, 6))
            .putInt("theme", next.theme.coerceIn(0, 3))
            .putInt("glass_alpha", next.glassAlpha.coerceIn(0, 40))
            .apply()
    }

    fun background(theme: Int): Color = when (theme.coerceIn(0, 3)) {
        1 -> Color(0xFF101B29)
        2 -> Color(0xFF171421)
        3 -> Color(0xFF17201E)
        else -> Color(0xFF101116)
    }
    fun accent(theme: Int): Color = when (theme.coerceIn(0, 3)) {
        1 -> Color(0xFF75C7FF)
        2 -> Color(0xFFC4A4FF)
        3 -> Color(0xFF9DD8B2)
        else -> Color(0xFF9DBBFF)
    }
}
