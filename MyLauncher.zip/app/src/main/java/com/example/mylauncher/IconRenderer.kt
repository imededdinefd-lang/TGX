package com.example.mylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.Drawable

/**
 * يحافظ على أيقونة Android الأصلية كما هي: لا إطار، لا قناع إضافي، لا قصّ، ولا تغيير ألوان.
 * نرسم Drawable في مساحة شفافة مربعة مع الحفاظ على نسبة أبعاده، ثم نخزّن الناتج مؤقتاً.
 */
object IconRenderer {
    const val TILE = 192
    const val SCALE = 1.0f
    const val VERSION = 4

    class Result(val bitmap: Bitmap, val accent: Int)

    fun fromDrawable(drawable: Drawable, size: Int = TILE): Bitmap {
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val intrinsicWidth = drawable.intrinsicWidth.takeIf { it > 0 } ?: size
        val intrinsicHeight = drawable.intrinsicHeight.takeIf { it > 0 } ?: size
        val scale = minOf(size.toFloat() / intrinsicWidth, size.toFloat() / intrinsicHeight)
        val width = (intrinsicWidth * scale).toInt().coerceAtLeast(1)
        val height = (intrinsicHeight * scale).toInt().coerceAtLeast(1)
        val left = (size - width) / 2
        val top = (size - height) / 2
        val safeDrawable = drawable.mutate()
        safeDrawable.bounds = Rect(left, top, left + width, top + height)
        safeDrawable.draw(canvas)
        return output
    }

    fun render(raw: Bitmap): Result {
        // نسخة مستقلة حتى يمكن تحرير الصورة المؤقتة بعد إنشاء نتيجة التخزين.
        val clean = raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
        return Result(clean, dominantColor(clean))
    }

    private fun dominantColor(src: Bitmap): Int {
        val sample = Bitmap.createScaledBitmap(src, 20, 20, true)
        var red = 0L
        var green = 0L
        var blue = 0L
        var count = 0
        for (y in 0 until sample.height) {
            for (x in 0 until sample.width) {
                val pixel = sample.getPixel(x, y)
                if (Color.alpha(pixel) < 96) continue
                red += Color.red(pixel)
                green += Color.green(pixel)
                blue += Color.blue(pixel)
                count++
            }
        }
        if (sample !== src) sample.recycle()
        if (count == 0) return Color.GRAY
        return Color.rgb((red / count).toInt(), (green / count).toInt(), (blue / count).toInt())
    }
}
