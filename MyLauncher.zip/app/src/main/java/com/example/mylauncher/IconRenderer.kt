package com.example.mylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader

/**
 * يرسم الأيقونة ثلاثية الأبعاد مرة واحدة فقط على صورة جاهزة.
 * هذا يحل بطء التنقل: بدل رسم الظلال والتدرجات لكل أيقونة في كل إطار،
 * تعرض الواجهة صورة واحدة بسيطة لكل تطبيق.
 * لون الحواف والسُّمك مأخوذ من اللون الغالب في أيقونة التطبيق نفسه.
 */
object IconRenderer {
    const val TILE = 192          // حجم اللوح بالبكسل
    const val SCALE = 1.22f       // الصورة أكبر من اللوح قليلاً لتتسع للظل
    const val VERSION = 3         // يزداد عند تغيير التصميم فتُعاد رسم الأيقونات المحفوظة

    class Result(val bitmap: Bitmap, val accent: Int)

    // تغيير سطوع/تشبع لون
    private fun shade(color: Int, v: Float, sat: Float = 1f): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = (hsv[1] * sat).coerceIn(0f, 1f)
        hsv[2] = (hsv[2] * v).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    // اللون الغالب: نجمع البكسلات في 12 مجموعة لونية ونأخذ الأقوى حضوراً
    private fun dominantColor(src: Bitmap): Int {
        val n = 24
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val hsv = FloatArray(3)
        val bw = DoubleArray(12)
        val br = DoubleArray(12)
        val bg = DoubleArray(12)
        val bb = DoubleArray(12)
        var ar = 0L
        var ag = 0L
        var ab = 0L
        var cnt = 0
        for (y in 0 until n) {
            for (x in 0 until n) {
                val p = small.getPixel(x, y)
                if (Color.alpha(p) < 200) continue
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                ar += r
                ag += g
                ab += b
                cnt++
                Color.colorToHSV(p, hsv)
                val w = (hsv[1] * hsv[2]).toDouble()
                val bin = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                bw[bin] += w
                br[bin] += r * w
                bg[bin] += g * w
                bb[bin] += b * w
            }
        }
        if (small !== src) small.recycle()
        if (cnt == 0) return 0xFF7A7F99.toInt()
        var best = 0
        for (i in 1 until 12) if (bw[i] > bw[best]) best = i
        // أيقونة رمادية أو بيضاء: نستخدم المتوسط العام
        if (bw[best] < 2.0) {
            return Color.rgb((ar / cnt).toInt(), (ag / cnt).toInt(), (ab / cnt).toInt())
        }
        return Color.rgb(
            (br[best] / bw[best]).toInt(),
            (bg[best] / bw[best]).toInt(),
            (bb[best] / bw[best]).toInt()
        )
    }

    // رفع سطوع/تشبع لون الدلالة ليظهر بوضوح على اللوح الداكن (دون تلوين الألوان الرمادية)
    private fun lift(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[2] = maxOf(hsv[2], 0.85f)
        if (hsv[1] > 0.15f) hsv[1] = maxOf(hsv[1], 0.45f)
        return Color.HSVToColor(hsv)
    }

    /**
     * التصميم الجديد "الإطار": لوح داكن مائل إلى لون التطبيق، حدّ رفيع بلون التطبيق،
     * الأيقونة الأصلية داخل إطار ناعم في الوسط، ومؤشّر صغير مضيء أسفلها (توقيع My Launcher).
     * لا لمعات ولا طبقات سُمك: شكل نظيف وهادئ، ورسمه رخيص لأنه يُرسم مرة واحدة.
     */
    fun render(raw: Bitmap): Result {
        val accent = dominantColor(raw)
        val bright = lift(accent)
        val s = TILE.toFloat()
        val w = (s * SCALE).toInt()
        val out = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        val left = (w - s) / 2f
        val top = (w - s) / 2f
        val plate = RectF(left, top, left + s, top + s)
        val radius = s * 0.27f

        // خلفية عميقة محايدة مع تلميح لوني خاص بكل تطبيق.
        val base = Paint(Paint.ANTI_ALIAS_FLAG)
        base.shader = LinearGradient(
            plate.left, plate.top, plate.right, plate.bottom,
            0xFF252638.toInt(), 0xFF10111B.toInt(), Shader.TileMode.CLAMP
        )
        base.setShadowLayer(s * 0.075f, 0f, s * 0.035f, 0x99000000.toInt())
        c.drawRoundRect(plate, radius, radius, base)

        // هالة لونية داخلية رقيقة تمنح كل تطبيق بصمته دون طمس ألوان الأيقونة.
        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.shader = LinearGradient(
            plate.left, plate.top, plate.right, plate.bottom,
            (bright and 0x00FFFFFF) or (0x35 shl 24),
            (bright and 0x00FFFFFF) or (0x05 shl 24),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(plate, radius, radius, glow)

        // إطار خارجي مزدوج: حد هادئ ثم لمسة ضوء في الأعلى.
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = s * 0.012f
            color = 0x66FFFFFF
        }
        c.drawRoundRect(
            RectF(plate.left + s * 0.008f, plate.top + s * 0.008f,
                plate.right - s * 0.008f, plate.bottom - s * 0.008f),
            radius, radius, border
        )
        val accentRail = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bright
            strokeWidth = s * 0.035f
            strokeCap = Paint.Cap.ROUND
            setShadowLayer(s * 0.035f, 0f, 0f, bright)
        }
        c.drawLine(plate.left + s * 0.22f, plate.top + s * 0.13f,
            plate.left + s * 0.43f, plate.top + s * 0.13f, accentRail)

        // حاضنة داخلية فاتحة ومنفصلة بوضوح عن خلفية اللوح.
        val size = s * 0.68f
        val ix = plate.left + (s - size) / 2f
        val iy = plate.top + (s - size) / 2f + s * 0.015f
        val iconRect = RectF(ix, iy, ix + size, iy + size)
        val holder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x1EFFFFFF
            setShadowLayer(s * 0.025f, 0f, s * 0.012f, 0x66000000)
        }
        c.drawRoundRect(iconRect, size * 0.25f, size * 0.25f, holder)

        // قصّ الأيقونة الأصلية داخل الحاضنة بحواف متناسقة.
        val inset = s * 0.045f
        val imageRect = RectF(
            iconRect.left + inset, iconRect.top + inset,
            iconRect.right - inset, iconRect.bottom - inset
        )
        val layer = c.saveLayer(imageRect, null)
        c.drawBitmap(raw, null, imageRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        c.drawRoundRect(imageRect, size * 0.20f, size * 0.20f, mask)
        c.restoreToCount(layer)

        // نقطة تعريف صغيرة في الركن السفلي بدلاً من الزخارف الثقيلة.
        val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bright
            setShadowLayer(s * 0.035f, 0f, 0f, bright)
        }
        c.drawCircle(plate.right - s * 0.17f, plate.bottom - s * 0.16f, s * 0.025f, marker)

        return Result(out, accent)
    }
}
