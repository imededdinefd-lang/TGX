package com.example.mylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader

/**
 * يرسم الأيقونة ثلاثية الأبعاد مرة واحدة فقط على صورة جاهزة.
 * هذا يحل بطء التنقل: بدل رسم الظلال والتدرجات لكل أيقونة في كل إطار،
 * تعرض الواجهة صورة واحدة بسيطة لكل تطبيق.
 * لون الحواف والسُّمك مأخوذ من اللون الغالب في أيقونة التطبيق نفسه.
 */
object IconRenderer {
    const val TILE = 192          // حجم اللوح بالبكسل
    const val SCALE = 1.22f       // الصورة أكبر من اللوح قليلاً لتتسع للظل
    const val VERSION = 2         // يزداد عند تغيير التصميم فتُعاد رسم الأيقونات المحفوظة

    class Result(val bitmap: Bitmap, val accent: Int)

    // تغيير سطوع/تشبع لون
    private fun shade(color: Int, v: Float, sat: Float = 1f): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = (hsv[1] * sat).coerceIn(0f, 1f)
        hsv[2] = (hsv[2] * v).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    // اللون الغالب: نجمع البكسلات في 12 مجموعة لونية ونأخذ الأقوى حضوراً
    private fun dominantColor(src: Bitmap): Int {
        val n = 24
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val hsv = FloatArray(3)
        val bw = DoubleArray(12)
        val br = DoubleArray(12)
        val bg = DoubleArray(12)
        val bb = DoubleArray(12)
        var ar = 0L
        var ag = 0L
        var ab = 0L
        var cnt = 0
        for (y in 0 until n) {
            for (x in 0 until n) {
                val p = small.getPixel(x, y)
                if (Color.alpha(p) < 200) continue
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                ar += r
                ag += g
                ab += b
                cnt++
                Color.colorToHSV(p, hsv)
                val w = (hsv[1] * hsv[2]).toDouble()
                val bin = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                bw[bin] += w
                br[bin] += r * w
                bg[bin] += g * w
                bb[bin] += b * w
            }
        }
        if (small !== src) small.recycle()
        if (cnt == 0) return 0xFF7A7F99.toInt()
        var best = 0
        for (i in 1 until 12) if (bw[i] > bw[best]) best = i
        // أيقونة رمادية أو بيضاء: نستخدم المتوسط العام
        if (bw[best] < 2.0) {
            return Color.rgb((ar / cnt).toInt(), (ag / cnt).toInt(), (ab / cnt).toInt())
        }
        return Color.rgb(
            (br[best] / bw[best]).toInt(),
            (bg[best] / bw[best]).toInt(),
            (bb[best] / bw[best]).toInt()
        )
    }

    // رفع سطوع/تشبع لون الدلالة ليظهر بوضوح على اللوح الداكن (دون تلوين الألوان الرمادية)
    private fun lift(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[2] = maxOf(hsv[2], 0.85f)
        if (hsv[1] > 0.15f) hsv[1] = maxOf(hsv[1], 0.45f)
        return Color.HSVToColor(hsv)
    }

    /**
     * التصميم الجديد "الإطار": لوح داكن مائل إلى لون التطبيق، حدّ رفيع بلون التطبيق،
     * الأيقونة الأصلية داخل إطار ناعم في الوسط، ومؤشّر صغير مضيء أسفلها (توقيع My Launcher).
     * لا لمعات ولا طبقات سُمك: شكل نظيف وهادئ، ورسمه رخيص لأنه يُرسم مرة واحدة.
     */
    fun render(raw: Bitmap): Result {
        val accent = dominantColor(raw)
        val bright = lift(accent)
        val s = TILE.toFloat()
        val w = (s * SCALE).toInt()
        val out = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        val left = (w - s) / 2f
        val top = (w - s) / 2f - s * 0.03f
        val plate = RectF(left, top, left + s, top + s)
        val r = s * 0.30f

        // 1) اللوح: تدرج داكن مائل إلى لون التطبيق + ظل ناعم قصير
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.shader = LinearGradient(
            plate.left, plate.top, plate.left, plate.bottom,
            shade(accent, 0.36f, 0.75f), shade(accent, 0.15f, 0.65f),
            Shader.TileMode.CLAMP
        )
        fill.setShadowLayer(s * 0.07f, 0f, s * 0.035f, 0x73000000)
        c.drawRoundRect(plate, r, r, fill)

        // 2) حدّ رفيع بلون التطبيق يخفت نحو الأسفل
        val edge = s * 0.024f
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = edge
        border.shader = LinearGradient(
            plate.left, plate.top, plate.left, plate.bottom,
            (bright and 0x00FFFFFF) or (0xC8 shl 24), (bright and 0x00FFFFFF) or (0x48 shl 24),
            Shader.TileMode.CLAMP
        )
        val h = edge / 2f
        c.drawRoundRect(
            RectF(plate.left + h, plate.top + h, plate.right - h, plate.bottom - h),
            r - h, r - h, border
        )

        // 3) خط ضوء رفيع داخل الحافة العليا
        val hi = Paint(Paint.ANTI_ALIAS_FLAG)
        hi.strokeWidth = s * 0.012f
        hi.strokeCap = Paint.Cap.ROUND
        hi.color = 0x2EFFFFFF
        c.drawLine(plate.left + r * 0.85f, plate.top + s * 0.035f, plate.right - r * 0.85f, plate.top + s * 0.035f, hi)

        // 4) الأيقونة الأصلية داخل إطار ناعم (أصغر قليلاً من اللوح وأعلى من منتصفه)
        val size = s * 0.66f
        val ix = plate.left + (s - size) / 2f
        val iy = plate.top + (s - size) / 2f - s * 0.04f
        val iconRect = RectF(ix, iy, ix + size, iy + size)
        val ri = size * 0.28f
        val layer = c.saveLayer(iconRect, null)
        c.drawBitmap(raw, null, iconRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawRoundRect(iconRect, ri, ri, mask)
        c.restoreToCount(layer)

        // 5) مؤشّر التوقيع: كبسولة صغيرة مضيئة بلون التطبيق أسفل الأيقونة
        val pw = s * 0.26f
        val ph = s * 0.04f
        val cy = plate.top + s * 0.885f
        val pill = RectF(plate.centerX() - pw / 2f, cy - ph / 2f, plate.centerX() + pw / 2f, cy + ph / 2f)
        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.color = bright
        glow.setShadowLayer(s * 0.04f, 0f, 0f, (bright and 0x00FFFFFF) or (0xAA shl 24))
        c.drawRoundRect(pill, ph / 2f, ph / 2f, glow)

        return Result(out, accent)
    }
}
