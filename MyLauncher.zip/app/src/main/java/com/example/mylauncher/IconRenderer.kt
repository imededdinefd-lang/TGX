package com.example.mylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader

/**
 * يرسم الأيقونة ثلاثية الأبعاد مرة واحدة فقط على صورة جاهزة.
 * هذا يحل بطء التنقل: بدل رسم الظلال والتدرجات لكل أيقونة في كل إطار،
 * تعرض الواجهة صورة واحدة بسيطة لكل تطبيق.
 * لون الحواف والسُّمك مأخوذ من اللون الغالب في أيقونة التطبيق نفسه.
 */
object IconRenderer {
    const val TILE = 192          // حجم اللوح بالبكسل
    const val SCALE = 1.22f       // الصورة أكبر من اللوح قليلاً لتتسع للظل

    class Result(val bitmap: Bitmap, val accent: Int)

    // تغيير سطوع/تشبع لون
    private fun shade(color: Int, v: Float, sat: Float = 1f): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = (hsv[1] * sat).coerceIn(0f, 1f)
        hsv[2] = (hsv[2] * v).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    // اللون الغالب: نجمع البكسلات في 12 مجموعة لونية ونأخذ الأقوى حضوراً
    private fun dominantColor(src: Bitmap): Int {
        val n = 24
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val hsv = FloatArray(3)
        val bw = DoubleArray(12)
        val br = DoubleArray(12)
        val bg = DoubleArray(12)
        val bb = DoubleArray(12)
        var ar = 0L
        var ag = 0L
        var ab = 0L
        var cnt = 0
        for (y in 0 until n) {
            for (x in 0 until n) {
                val p = small.getPixel(x, y)
                if (Color.alpha(p) < 200) continue
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                ar += r
                ag += g
                ab += b
                cnt++
                Color.colorToHSV(p, hsv)
                val w = (hsv[1] * hsv[2]).toDouble()
                val bin = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                bw[bin] += w
                br[bin] += r * w
                bg[bin] += g * w
                bb[bin] += b * w
            }
        }
        if (small !== src) small.recycle()
        if (cnt == 0) return 0xFF7A7F99.toInt()
        var best = 0
        for (i in 1 until 12) if (bw[i] > bw[best]) best = i
        // أيقونة رمادية أو بيضاء: نستخدم المتوسط العام
        if (bw[best] < 2.0) {
            return Color.rgb((ar / cnt).toInt(), (ag / cnt).toInt(), (ab / cnt).toInt())
        }
        return Color.rgb(
            (br[best] / bw[best]).toInt(),
            (bg[best] / bw[best]).toInt(),
            (bb[best] / bw[best]).toInt()
        )
    }

    fun render(raw: Bitmap): Result {
        val accent = dominantColor(raw)
        val s = TILE.toFloat()
        val w = (s * SCALE).toInt()
        val out = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        val left = (w - s) / 2f
        val top = (w - s) / 2f - s * 0.05f
        val tile = RectF(left, top, left + s, top + s)
        val r = s * 0.30f
        val thick = s * 0.045f

        // 1) السُّمك + الظل: لوح داكن من لون التطبيق أسفل اللوح الرئيسي
        val slab = RectF(tile)
        slab.offset(0f, thick)
        val slabPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        slabPaint.color = shade(accent, 0.45f)
        slabPaint.setShadowLayer(s * 0.06f, 0f, s * 0.04f, 0x88000000.toInt())
        c.drawRoundRect(slab, r, r, slabPaint)

        // 2) اللوح الرئيسي بتدرج من لون التطبيق (أفتح في الأعلى وأغمق في الأسفل)
        val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        facePaint.shader = LinearGradient(
            tile.left, tile.top, tile.right, tile.bottom,
            shade(accent, 1.18f, 0.85f), shade(accent, 0.62f),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(tile, r, r, facePaint)

        // 3) حد لامع رفيع
        val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = s * 0.02f
        rim.shader = LinearGradient(
            tile.left, tile.top, tile.right, tile.bottom,
            intArrayOf(0xCCFFFFFF.toInt(), 0x00FFFFFF, 0x66FFFFFF),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        val half = s * 0.01f
        c.drawRoundRect(
            RectF(tile.left + half, tile.top + half, tile.right - half, tile.bottom - half),
            r - half, r - half, rim
        )

        // 4) أيقونة التطبيق داخل اللوح، بحواف ناعمة ولمعة ضوء
        val inset = s * 0.085f
        val iconRect = RectF(tile.left + inset, tile.top + inset, tile.right - inset, tile.bottom - inset)
        val ri = r - inset * 0.6f
        val layer = c.saveLayer(iconRect, null)
        val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(raw, null, iconRect, bmpPaint)
        // قناع بزوايا ناعمة
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawRoundRect(iconRect, ri, ri, mask)
        // لمعة من أعلى اليسار وظل في أسفل اليمين، فقط فوق رسم الأيقونة
        val gloss = Paint()
        gloss.shader = LinearGradient(
            iconRect.left, iconRect.top, iconRect.right, iconRect.bottom,
            intArrayOf(0x66FFFFFF, 0x00FFFFFF, 0x47000000),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        gloss.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        c.drawRect(iconRect, gloss)
        c.restoreToCount(layer)

        return Result(out, accent)
    }
}
