package com.example.mylauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.BatteryManager
import android.app.ActivityManager
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

// معلومات كل تطبيق: اسمه، حزمته، صورة الأيقونة الأصلية، ومتوسط لونها
@androidx.compose.runtime.Immutable
data class AppInfo(
    val label: String,
    val packageName: String,
    val tile: ImageBitmap,
    val accent: Int
)

class MainActivity : ComponentActivity() {

    // يزداد عند الضغط على Home، فتُغلق قائمة التطبيقات
    private var homeEvent by mutableIntStateOf(0)

    // يزداد عند العودة للواجهة، فنعيد قراءة الإعدادات والتطبيقات
    private var resumeEvent by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        // تحميل مسبق: تبدأ قراءة التطبيقات قبل رسم أول إطار، لا عند فتح القائمة
        AppRepo.refresh(this)
        setContent {
            LauncherScreen(homeEvent, resumeEvent)
        }
    }

    override fun onResume() {
        super.onResume()
        LauncherMotionSystem.refresh(this)
        AppRepo.refresh(this)
        resumeEvent++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeEvent++
    }
}

// ---------------------------------------------------------------------------
// تحميل التطبيقات (مع ذاكرة مؤقتة: تُرسم كل أيقونة مرة واحدة فقط)
// ---------------------------------------------------------------------------

// ذاكرة مؤقتة محدودة الحجم (32 ميجابايت). مفتاحها اسم الحزمة، وقيمتها الأيقونة الجاهزة.
// الأيقونات كلها بحجم ثابت (≈234px) فلا يُعاد تحويل أي Drawable أثناء التمرير.
object IconCache {
    private val lru = object : LruCache<String, AppInfo>(32 * 1024) {
        override fun sizeOf(key: String, value: AppInfo): Int =
            (value.tile.width * value.tile.height * 4) / 1024
    }
    val stamp = ConcurrentHashMap<String, Long>()

    fun get(pkg: String): AppInfo? = lru.get(pkg)
    fun put(pkg: String, app: AppInfo, stampValue: Long) {
        lru.put(pkg, app)
        stamp[pkg] = stampValue
    }
}

private class DiskEntry(val stamp: Long, val accent: Int, val label: String)

// تحميل التطبيقات: ذاكرة ← قرص ← رسم جديد. كل أيقونة تُرسم مرة واحدة في عمر التطبيق
// وتُحفظ على القرص، فلا يُعاد رسمها حتى لو أغلق النظام الواجهة بسبب ضغط الذاكرة.
suspend fun loadApps(context: Context, pm: PackageManager): List<AppInfo> =
    withContext(Dispatchers.IO) {
        val self = context.packageName
        val dir = File(context.cacheDir, "tiles").apply { mkdirs() }
        val indexFile = File(dir, "index.tsv")
        // الترويسة: لغة النظام + إصدار التصميم (عند تغيّر أي منهما تُعاد الأيقونات)
        val locale = Locale.getDefault().toString() + "#" + IconRenderer.VERSION

        // الفهرس المحفوظ: حزمة \t ختم \t لون \t اسم (يُهمَل عند تغيّر لغة النظام)
        val saved = HashMap<String, DiskEntry>()
        runCatching {
            val lines = indexFile.readLines()
            if (lines.isNotEmpty() && lines[0] == locale) {
                for (i in 1 until lines.size) {
                    val p = lines[i].split('\t', limit = 4)
                    if (p.size == 4) saved[p[0]] = DiskEntry(p[1].toLong(), p[2].toInt(), p[3])
                }
            }
        }

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != self }
            .distinctBy { it.activityInfo.packageName }

        val dirty = AtomicBoolean(false)
        val result = infos.map { ri ->
            async(Dispatchers.Default) {
                val pkg = ri.activityInfo.packageName
                // ختم زمني لملف التطبيق: يتغيّر عند تحديثه فنعيد رسم أيقونته
                val stamp = File(ri.activityInfo.applicationInfo.sourceDir).lastModified()

                val mem = IconCache.get(pkg)
                if (mem != null && IconCache.stamp[pkg] == stamp) return@async mem

                val file = File(dir, "$pkg.png")
                val e = saved[pkg]
                if (e != null && e.stamp == stamp && file.exists()) {
                    val bmp = BitmapFactory.decodeFile(file.path)
                    if (bmp != null) {
                        val app = AppInfo(e.label, pkg, bmp.asImageBitmap(), e.accent)
                        IconCache.put(pkg, app, stamp)
                        return@async app
                    }
                }

                val raw = IconRenderer.fromDrawable(ri.loadIcon(pm))
                val res = IconRenderer.render(raw)
                if (res.bitmap !== raw) raw.recycle()
                val label = ri.loadLabel(pm).toString()
                runCatching {
                    file.outputStream().use { res.bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                val app = AppInfo(label, pkg, res.bitmap.asImageBitmap(), res.accent)
                IconCache.put(pkg, app, stamp)
                dirty.set(true)
                app
            }
        }.awaitAll().sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })

        if (dirty.get() || saved.size != result.size) {
            runCatching {
                val sb = StringBuilder(locale).append('\n')
                for (a in result) {
                    sb.append(a.packageName).append('\t')
                        .append(IconCache.stamp[a.packageName] ?: 0L).append('\t')
                        .append(a.accent).append('\t')
                        .append(a.label.replace('\t', ' ').replace('\n', ' ')).append('\n')
                }
                indexFile.writeText(sb.toString())
            }
        }
        result
    }

// ---------------------------------------------------------------------------
// أيقونة التطبيق الأصلية: تُعرض دون إطار أو قص، مع حركة ضغط خفيفة
// ---------------------------------------------------------------------------

@Composable
fun LauncherIcon(
    app: AppInfo,
    tile: Dp,
    showLabel: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current
    // انكماش زنبركي من LauncherMotionSystem
    val scale by animateFloatAsState(
        targetValue = if (pressed) LauncherMotionSystem.PRESS_SCALE else 1f,
        animationSpec = LauncherMotionSystem.press(),
        label = "press"
    )
    val currentClick by rememberUpdatedState(onClick)
    val currentLong by rememberUpdatedState(onLongClick)

    Column(
        modifier = Modifier.pointerInput(app.packageName) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onLongPress = { currentLong?.invoke() },
                onTap = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    currentClick()
                }
            )
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.tile,
            contentDescription = app.label,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(tile)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
        )
        if (showLabel) {
            Text(
                text = app.label,
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(top = 3.dp)
                    .width(tile + 14.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// الشاشات
// ---------------------------------------------------------------------------

@Composable
fun LauncherScreen(homeEvent: Int, resumeEvent: Int) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val pm = context.packageManager

    val apps by AppRepo.apps.collectAsState()
    var showDrawer by remember { mutableStateOf(false) }
    var showControlCenter by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var homePkgs by remember { mutableStateOf(Prefs.loadHome(context)) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var dockPkgs by remember { mutableStateOf(Prefs.loadDock(context)) }
    val settings = remember(resumeEvent) { Prefs.load(context) }

    LaunchedEffect(homeEvent) {
        showDrawer = false
        showMenu = false
        showControlCenter = false
        menuApp = null
    }
    // تقدّم فتح القائمة (0 = مغلقة، 1 = مفتوحة). يُقرأ داخل graphicsLayer فقط
    // حتى لا تُعاد تركيبة الشاشة كل إطار أثناء الحركة.
    val progress = remember { Animatable(0f) }
    LaunchedEffect(showDrawer) {
        if (!showDrawer) {
            query = ""
            focusManager.clearFocus()
        }
        val target = if (showDrawer) 1f else 0f
        if (LauncherMotionSystem.reduced) {
            progress.snapTo(target)
        } else {
            progress.animateTo(
                target,
                spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = if (showDrawer) Spring.StiffnessMediumLow else Spring.StiffnessMedium
                )
            )
        }
    }
    BackHandler(enabled = showControlCenter) { showControlCenter = false }
    BackHandler(enabled = showDrawer) { showDrawer = false }
    BackHandler(enabled = showMenu) { showMenu = false }
    BackHandler(enabled = menuApp != null) { menuApp = null }

    // الشريط السفلي يختاره المستخدم فقط؛ لا نقتبس شيئاً من واجهة الهاتف تلقائياً
    val dock = remember(apps, dockPkgs, settings.dockCount) {
        val byPkg = apps.associateBy { it.packageName }
        dockPkgs.mapNotNull { byPkg[it] }.take(settings.dockCount)
    }

    fun launch(app: AppInfo) {
        focusManager.clearFocus()
        // نفتح التطبيق في مهمته الخاصة، ونترك واجهتنا حيّة في الخلفية (لا finish ولا CLEAR_TASK)
        pm.getLaunchIntentForPackage(app.packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            context.startActivity(it)
        }
        showDrawer = false
    }

    fun setHome(list: List<String>) {
        homePkgs = list
        Prefs.saveHome(context, list)
    }

    fun setDock(list: List<String>) {
        dockPkgs = list
        Prefs.saveDock(context, list)
    }

    // تطبيقات الشاشة الرئيسية بالترتيب المحفوظ (نتجاهل ما أُلغي تثبيته)
    val homeApps = remember(apps, homePkgs) {
        val byPkg = apps.associateBy { it.packageName }
        homePkgs.mapNotNull { byPkg[it] }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(showDrawer) {
                // ضغطتان على مكان فارغ من الشاشة الرئيسية
                if (!showDrawer) {
                    detectTapGestures(onDoubleTap = {
                        GestureService.perform(context, Prefs.getInt(context, "gDouble", GestureAction.NONE))
                    })
                }
            }
    ) {
        AuroraBackground(settings.theme)

        // الشاشة الرئيسية تبقى مركّبة دائماً (لا إعادة بناء عند كل فتح/إغلاق)،
        // وتخفت بسرعة في أول الحركة كي لا يظهر تراكب الشاشتين.
        run {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = progress.value
                        alpha = (1f - 2.2f * p).coerceIn(0f, 1f)
                        val sc = 1f - 0.05f * p
                        scaleX = sc
                        scaleY = sc
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
                    .pointerInput(Unit) {
                        // الضغط المطوّل على مكان فارغ يفتح الإعدادات
                        detectTapGestures(
                            onLongPress = {
                                context.startActivity(Intent(context, SettingsActivity::class.java))
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        // السحب للأعلى يفتح القائمة
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total < -80f) {
                                    focusSearch = false
                                    showDrawer = true
                                }
                            },
                            onVerticalDrag = { _, d -> total += d }
                        )
                    }
            ) {
                HomeScreen(
                    dock = dock,
                    homeApps = homeApps,
                    tile = settings.tileDp.dp,
                    onLongPress = { menuApp = it },
                    onOpenSearch = {
                        focusSearch = true
                        showDrawer = true
                    },
                    onOpenDrawer = {
                        focusSearch = false
                        showDrawer = true
                    },
                    onLaunch = { launch(it) }
                )
                // مدخل مركز التحكم يحل محل زر الإعدادات العلوي؛ الإعدادات متاحة من الدرج فقط.
                ControlCenterHandle(
                    onClick = { showControlCenter = true },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 12.dp, end = 20.dp)
                )
            }
        }

        // القائمة مركّبة مسبقاً وخارج الشاشة، فلا تكلّفة تركيب عند أول فتح.
        // عند الإغلاق تكون خارج حدود الشاشة فلا تستقبل اللمس ولا تُرسم.
        run {
            AppDrawer(
                modifier = Modifier.graphicsLayer {
                    val p = progress.value
                    translationY = (1f - p) * size.height
                    alpha = ((p - 0.25f) / 0.75f).coerceIn(0f, 1f)
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                },
                visible = showDrawer,
                apps = apps,
                settings = settings,
                query = query,
                onQuery = { query = it },
                autoFocus = focusSearch,
                onClose = {
                    focusManager.clearFocus()
                    showDrawer = false
                },
                onLaunch = { launch(it) },
                onLongPress = { menuApp = it },
                onSettings = { context.startActivity(Intent(context, SettingsActivity::class.java)) }
            )
        }

        if (showControlCenter) {
            ModernControlCenter(
                onDismiss = { showControlCenter = false },
                onOpenSettings = { action ->
                    showControlCenter = false
                    runCatching { context.startActivity(Intent(action)) }
                }
            )
        }

        // قائمة الضغط المطوّل على تطبيق
        menuApp?.let { app ->
            AppMenu(
                app = app,
                inHome = app.packageName in homePkgs,
                inDock = app.packageName in dockPkgs,
                onToggleDock = {
                    if (app.packageName in dockPkgs) {
                        setDock(dockPkgs - app.packageName)
                    } else if (dock.size >= settings.dockCount) {
                        Toast.makeText(
                            context,
                            "الشريط السفلي ممتلئ (${settings.dockCount}). أزل تطبيقاً أو زد العدد من الإعدادات",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        setDock(dockPkgs + app.packageName)
                    }
                    menuApp = null
                },
                onToggleHome = {
                    if (app.packageName in homePkgs) setHome(homePkgs - app.packageName)
                    else setHome(homePkgs + app.packageName)
                    menuApp = null
                },
                onInfo = {
                    menuApp = null
                    context.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")
                        )
                    )
                },
                onUninstall = {
                    menuApp = null
                    context.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    )
                },
                onDismiss = { menuApp = null }
            )
        }
    }
}

@Composable
fun HomeScreen(
    dock: List<AppInfo>,
    homeApps: List<AppInfo>,
    tile: Dp,
    onLongPress: (AppInfo) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenDrawer: () -> Unit,
    onLaunch: (AppInfo) -> Unit
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 32.dp, end = 32.dp, top = 56.dp)
        ) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
                color = Color.White,
                fontSize = 64.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 18.sp
            )
        }

        SmartGlancePager(Modifier.padding(horizontal = 20.dp, vertical = 12.dp))

        // شبكة الشاشة الرئيسية (صفحات)
        HomeGrid(
            apps = homeApps,
            tile = tile,
            onLaunch = onLaunch,
            onLongPress = onLongPress,
            onOpenDrawer = onOpenDrawer,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        )

        // مستطيل البحث: صغير بحواف منحنية في وسط الشاشة
        Row(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 12.dp)
                .fillMaxWidth(0.72f)
                .height(46.dp)
                .glass(RoundedCornerShape(18.dp))
                .tappable(onOpenSearch)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            Text(
                text = "ابحث في هاتفك",
                color = Color.White.copy(alpha = 0.65f),
                fontSize = 15.sp
            )
        }

        // بطاقة المفضلة: مساحة مستقلة لا تُملأ تلقائياً من واجهة الهاتف.
        Column(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 16.dp)
                .glass(RoundedCornerShape(32.dp), strength = 0.92f, shadowed = true)
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (dock.isEmpty()) {
                    Text(
                        text = "أضف تطبيقاتك المفضلة من القائمة",
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
                    )
                } else {
                    dock.take(5).forEach { app ->
                        Box(Modifier.padding(horizontal = 2.dp)) {
                            LauncherIcon(app, 46.dp, false, { onLongPress(app) }) { onLaunch(app) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlCenterHandle(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.padding(top = 12.dp, end = 20.dp).size(46.dp)
            .glass(RoundedCornerShape(17.dp), strength = 0.9f)
            .tappable(onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("⌁", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun SmartGlancePager(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var battery by remember { mutableIntStateOf(
        (context.getSystemService(BatteryManager::class.java)
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0).coerceIn(0, 100)
    ) }
    var memoryPercent by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        val manager = context.getSystemService(ActivityManager::class.java)
        while (true) {
            now = LocalDateTime.now()
            battery = (context.getSystemService(BatteryManager::class.java)
                ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: battery).coerceIn(0, 100)
            val info = ActivityManager.MemoryInfo()
            manager?.getMemoryInfo(info)
            memoryPercent = if (info.totalMem > 0)
                (((info.totalMem - info.availMem).toDouble() / info.totalMem) * 100).toInt() else 0
            delay(30_000)
        }
    }
    val pager = rememberPagerState(pageCount = { 3 })
    HorizontalPager(state = pager, modifier = modifier.fillMaxWidth().height(104.dp), pageSpacing = 10.dp) { page ->
        val title = when (page) { 0 -> "نظرة سريعة"; 1 -> "حالة الجهاز"; else -> "الطقس" }
        Row(
            Modifier.fillMaxSize().glass(RoundedCornerShape(25.dp), strength = 0.82f, shadowed = false)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, color = Color.White.copy(alpha = 0.62f), fontSize = 11.sp)
                when (page) {
                    0 -> {
                        Text(now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", Locale.getDefault())), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                    }
                    1 -> {
                        Text("البطارية $battery%", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text("استخدام الذاكرة $memoryPercent%", color = Color.White.copy(alpha = 0.72f), fontSize = 12.sp)
                    }
                    else -> {
                        Text("الطقس المحلي", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text("يتطلب مزود طقس للحصول على بيانات مباشرة", color = Color.White.copy(alpha = 0.68f), fontSize = 11.sp)
                    }
                }
            }
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) {
                Text(when (page) { 0 -> "◷"; 1 -> "▤"; else -> "☼" }, color = Color.White, fontSize = 25.sp)
            }
        }
    }
}

@Composable
private fun ModernControlCenter(onDismiss: () -> Unit, onOpenSettings: (String) -> Unit) {
    val haptics = LocalHapticFeedback.current
    var brightness by remember { mutableStateOf(0.55f) }
    val audio = LocalContext.current.getSystemService(AudioManager::class.java)
    val maxVolume = (audio?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15).coerceAtLeast(1)
    var volume by remember { mutableStateOf(
        (audio?.getStreamVolume(AudioManager.STREAM_MUSIC)?.toFloat() ?: 0f) / maxVolume
    ) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)).tappable(onDismiss)) {
        Column(
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)
                .fillMaxWidth(0.94f).glass(RoundedCornerShape(30.dp), strength = 1f)
                .padding(16.dp).tappable { },
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مركز التحكم", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("اختصارات النظام", color = Color.White.copy(alpha = 0.58f), fontSize = 12.sp)
                }
                Text("✕", color = Color.White, fontSize = 20.sp, modifier = Modifier.tappable(onDismiss).padding(8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ControlTile("Wi-Fi", "◉", Modifier.weight(1f)) { onOpenSettings(android.provider.Settings.ACTION_WIFI_SETTINGS) }
                ControlTile("Bluetooth", "ᛒ", Modifier.weight(1f)) { onOpenSettings(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f).glass(RoundedCornerShape(22.dp)).padding(12.dp)) {
                    Text("سطوع المعاينة", color = Color.White, fontSize = 13.sp)
                    Slider(value = brightness, onValueChange = { brightness = it; haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove) })
                }
                Column(Modifier.weight(1f).glass(RoundedCornerShape(22.dp)).padding(12.dp)) {
                    Text("صوت الوسائط", color = Color.White, fontSize = 13.sp)
                    Slider(value = volume, onValueChange = {
                        volume = it
                        audio?.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVolume).toInt(), 0)
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ControlTile("الشاشة", "▣", Modifier.weight(1f)) { onOpenSettings(android.provider.Settings.ACTION_DISPLAY_SETTINGS) }
                ControlTile("الصوت", "♫", Modifier.weight(1f)) { onOpenSettings(android.provider.Settings.ACTION_SOUND_SETTINGS) }
                ControlTile("البطارية", "ϟ", Modifier.weight(1f)) { onOpenSettings(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS) }
            }
            Text("تُفتح إعدادات النظام الأصلية للخيارات التي يحظر Android تغييرها مباشرةً على تطبيقات الطرف الثالث.", color = Color.White.copy(alpha = 0.56f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ControlTile(label: String, glyph: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(76.dp).glass(RoundedCornerShape(21.dp), strength = 0.9f)
            .tappable(onClick).padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(glyph, color = Color.White, fontSize = 21.sp)
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AppDrawer(
    modifier: Modifier = Modifier,
    visible: Boolean,
    apps: List<AppInfo>,
    settings: LauncherSettings,
    query: String,
    onQuery: (String) -> Unit,
    autoFocus: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onSettings: () -> Unit
) {
    // التصفية على خيط خلفي مع تأخير بسيط (debounce)، وتبقى النتيجة السابقة ظاهرة أثناء الحساب
    val filtered by produceState(initialValue = apps, apps, query) {
        if (query.isBlank()) {
            value = apps
        } else {
            delay(120)
            val q = query.trim()
            value = withContext(Dispatchers.Default) {
                apps.filter { it.label.contains(q, ignoreCase = true) }
            }
        }
    }
    val focusRequester = remember { FocusRequester() }

    val gridState = rememberLazyGridState()
    LaunchedEffect(visible) {
        if (visible) {
            if (autoFocus) runCatching { focusRequester.requestFocus() }
        } else {
            // بعد انتهاء حركة الإغلاق نعيد القائمة إلى أولها
            delay(300)
            gridState.scrollToItem(0)
        }
    }

    Column(
        modifier
            .fillMaxSize()
            // يمنع وصول اللمس إلى الشاشة الرئيسية التي تحته
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black.copy(alpha = 0.35f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // مقبض: اسحب للأسفل لإغلاق القائمة
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 60f) onClose() },
                        onVerticalDrag = { _, d -> total += d }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.4f))
            )
        }

        // حقل البحث
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(48.dp)
                .glass(RoundedCornerShape(18.dp), shadowed = false)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { filtered.firstOrNull()?.let(onLaunch) }
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                text = "ابحث في هاتفك",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 16.sp
                            )
                        }
                        inner()
                    }
                }
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("كل التطبيقات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Text("${filtered.size} تطبيق", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            }
            GearButton(onClick = onSettings)
        }

        if (filtered.isEmpty() && apps.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد نتائج", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
            }
        }

        val tile = settings.tileDp.dp
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(settings.columns),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered, key = { it.packageName }, contentType = { "app" }) { app ->
                Box(Modifier.fillMaxWidth().padding(vertical = 2.dp), contentAlignment = Alignment.Center) {
                    LauncherIcon(app, tile, settings.labels, { onLongPress(app) }) { onLaunch(app) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// قائمة الشاشة الرئيسية
// ---------------------------------------------------------------------------

// زر زجاجي دائري بثلاث نقاط
@Composable
fun MenuButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(40.dp)
            .glass(CircleShape)
            .tappable(onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            val c = Color.White.copy(alpha = 0.85f)
            val r = 2.dp.toPx()
            for (i in 0..2) {
                drawCircle(c, r, Offset(size.width / 2f, size.height * (0.15f + 0.35f * i)))
            }
        }
    }
}

// نافذة زجاجية صغيرة تحتوي الخيارات
@Composable
fun HomeMenu(onSettings: () -> Unit, onHomeChooser: () -> Unit, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().tappable(onDismiss)) {
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 64.dp, end = 20.dp)
                .width(260.dp)
                .glass(RoundedCornerShape(20.dp))
                .padding(vertical = 6.dp)
        ) {
            MenuItem("إعدادات الواجهة", onSettings)
            MenuItem("الشاشة الرئيسية الافتراضية", onHomeChooser)
        }
    }
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 15.sp,
        modifier = Modifier
            .fillMaxWidth()
            .tappable(onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp)
    )
}

// ---------------------------------------------------------------------------
// شبكة الشاشة الرئيسية (صفحات قابلة للتمرير)
// ---------------------------------------------------------------------------
@Composable
fun HomeGrid(
    apps: List<AppInfo>,
    tile: Dp,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier) {
        val cols = 4
        val cellH = tile + 28.dp
        val rows = ((maxHeight - 24.dp) / cellH).toInt().coerceIn(1, 6)
        val perPage = cols * rows
        val pageCount = maxOf(1, (apps.size + perPage - 1) / perPage)

        if (apps.isEmpty()) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.86f)
                    .plate(RoundedCornerShape(26.dp))
                    .padding(horizontal = 22.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                }
                Text("مساحتك تبدأ هنا", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                Text(
                    "أضف التطبيقات التي تختارها إلى هذه الشاشة. سيبقى ترتيب واجهة الهاتف الأصلية مستقلاً تماماً.",
                    color = Color.White.copy(alpha = 0.62f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    "استعراض التطبيقات  ›",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .tappable(onOpenDrawer)
                        .padding(horizontal = 20.dp, vertical = 11.dp)
                )
            }
        } else {
            val pagerState = rememberPagerState(pageCount = { pageCount })
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                val start = page * perPage
                val pageApps = apps.drop(start).take(perPage)
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    for (r in 0 until rows) {
                        Row(Modifier.fillMaxWidth().height(cellH)) {
                            for (c in 0 until cols) {
                                val app = pageApps.getOrNull(r * cols + c)
                                Box(
                                    Modifier.weight(1f).height(cellH),
                                    contentAlignment = Alignment.TopCenter
                                ) {
                                    if (app != null) {
                                        LauncherIcon(app, tile, true, { onLongPress(app) }) { onLaunch(app) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (pageCount > 1) {
                PageDots(
                    current = pagerState.currentPage,
                    count = pageCount,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
fun PageDots(current: Int, count: Int, modifier: Modifier = Modifier) {
    Row(
        modifier
            .glass(RoundedCornerShape(50), 0.6f)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0 until count) {
            Box(
                Modifier
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.4f))
            )
        }
    }
}

// قائمة الضغط المطوّل على تطبيق
@Composable
fun AppMenu(
    app: AppInfo,
    inHome: Boolean,
    inDock: Boolean,
    onToggleDock: () -> Unit,
    onToggleHome: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .tappable(onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(280.dp)
                .plate(RoundedCornerShape(26.dp))
                .tappable { }
                .padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                bitmap = app.tile,
                contentDescription = app.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(64.dp)
            )
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            MenuItem(
                if (inHome) "إزالة من الشاشة الرئيسية" else "إضافة إلى الشاشة الرئيسية",
                onToggleHome
            )
            MenuItem(
                if (inDock) "إزالة من الشريط السفلي" else "إضافة إلى الشريط السفلي",
                onToggleDock
            )
            MenuItem("معلومات التطبيق", onInfo)
            MenuItem("إلغاء التثبيت", onUninstall)
        }
    }
}
