package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// معلومات كل تطبيق: اسمه، حزمته، صورة الأيقونة الجاهزة، ولونه الغالب
data class AppInfo(
    val label: String,
    val packageName: String,
    val tile: ImageBitmap,
    val accent: Int
)

class MainActivity : ComponentActivity() {

    // يزداد عند الضغط على Home، فتُغلق قائمة التطبيقات
    private var homeEvent by mutableIntStateOf(0)

    // يزداد عند العودة للواجهة، فنعيد قراءة الإعدادات والتطبيقات
    private var resumeEvent by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            LauncherScreen(homeEvent, resumeEvent)
        }
    }

    override fun onResume() {
        super.onResume()
        resumeEvent++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeEvent++
    }
}

// ---------------------------------------------------------------------------
// تحميل التطبيقات (مع ذاكرة مؤقتة: تُرسم كل أيقونة مرة واحدة فقط)
// ---------------------------------------------------------------------------

object IconCache {
    val map = HashMap<String, AppInfo>()
}

fun loadApps(pm: PackageManager, self: String): List<AppInfo> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != self }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val pkg = ri.activityInfo.packageName
            IconCache.map.getOrPut(pkg) {
                val raw = ri.loadIcon(pm).toBitmap(192, 192)
                val res = IconRenderer.render(raw)
                AppInfo(ri.loadLabel(pm).toString(), pkg, res.bitmap.asImageBitmap(), res.accent)
            }
        }
        .sortedBy { it.label.lowercase() }
}

// اختيار تطبيقات الشريط السفلي: الهاتف، الرسائل، الكاميرا، المتصفح
fun resolveDock(pm: PackageManager, apps: List<AppInfo>, count: Int): List<AppInfo> {
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
    )
    val result = mutableListOf<AppInfo>()
    for (i in intents) {
        val pkg = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val app = apps.firstOrNull { it.packageName == pkg }
        if (app != null && app !in result) result.add(app)
    }
    // إن لم نجد العدد المطلوب نكمل من أول القائمة
    for (app in apps) {
        if (result.size >= count) break
        if (app !in result) result.add(app)
    }
    return result.take(count)
}

// ---------------------------------------------------------------------------
// أيقونة التطبيق: صورة جاهزة + تأثير ضغط خفيف
// ---------------------------------------------------------------------------

@Composable
fun Icon3D(app: AppInfo, tile: Dp, showLabel: Boolean, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.90f else 1f, label = "press")
    val currentClick by rememberUpdatedState(onClick)

    Column(
        modifier = Modifier.pointerInput(app.packageName) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { currentClick() }
            )
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.tile,
            contentDescription = app.label,
            modifier = Modifier
                .size(tile * IconRenderer.SCALE)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
        )
        if (showLabel) {
            Text(
                text = app.label,
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(tile + 14.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// الشاشات
// ---------------------------------------------------------------------------

@Composable
fun LauncherScreen(homeEvent: Int, resumeEvent: Int) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val pm = context.packageManager

    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var showDrawer by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val settings = remember(resumeEvent) { Prefs.load(context) }

    // تحميل التطبيقات في الخلفية (الأيقونات المرسومة سابقاً تُؤخذ من الذاكرة)
    LaunchedEffect(resumeEvent) {
        apps = withContext(Dispatchers.Default) { loadApps(pm, context.packageName) }
    }
    LaunchedEffect(homeEvent) { showDrawer = false }
    LaunchedEffect(showDrawer) { if (!showDrawer) query = "" }
    BackHandler(enabled = showDrawer) { showDrawer = false }

    val dock = remember(apps, settings.dockCount) { resolveDock(pm, apps, settings.dockCount) }

    fun launch(app: AppInfo) {
        focusManager.clearFocus()
        pm.getLaunchIntentForPackage(app.packageName)?.let { context.startActivity(it) }
        showDrawer = false
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(settings.theme)

        AnimatedVisibility(
            visible = !showDrawer,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // الضغط المطوّل على مكان فارغ يفتح الإعدادات
                        detectTapGestures(
                            onLongPress = {
                                context.startActivity(Intent(context, SettingsActivity::class.java))
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        // السحب للأعلى يفتح القائمة
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total < -80f) {
                                    focusSearch = false
                                    showDrawer = true
                                }
                            },
                            onVerticalDrag = { _, d -> total += d }
                        )
                    }
            ) {
                HomeScreen(
                    dock = dock,
                    onOpenSearch = {
                        focusSearch = true
                        showDrawer = true
                    },
                    onLaunch = { launch(it) }
                )
            }
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = fadeIn() + slideInVertically { it / 10 },
            exit = fadeOut() + slideOutVertically { it / 10 }
        ) {
            AppDrawer(
                apps = apps,
                settings = settings,
                query = query,
                onQuery = { query = it },
                autoFocus = focusSearch,
                onClose = {
                    focusManager.clearFocus()
                    showDrawer = false
                },
                onLaunch = { launch(it) }
            )
        }
    }
}

@Composable
fun HomeScreen(dock: List<AppInfo>, onOpenSearch: () -> Unit, onLaunch: (AppInfo) -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 32.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
                color = Color.White,
                fontSize = 88.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 20.sp
            )
        }

        // مستطيل البحث: صغير بحواف منحنية في وسط الشاشة
        Row(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 12.dp)
                .fillMaxWidth(0.72f)
                .height(46.dp)
                .glass(RoundedCornerShape(18.dp))
                .tappable(onOpenSearch)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            Text(
                text = "ابحث في هاتفك",
                color = Color.White.copy(alpha = 0.65f),
                fontSize = 15.sp
            )
        }

        // الشريط السفلي: أضيق، يلتف حول الأيقونات فقط
        if (dock.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 16.dp)
                    .glass(RoundedCornerShape(26.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                dock.forEach { app ->
                    Icon3D(app, 48.dp, false) { onLaunch(app) }
                }
            }
        }
    }
}

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    settings: LauncherSettings,
    query: String,
    onQuery: (String) -> Unit,
    autoFocus: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit
) {
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps
        else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (autoFocus) runCatching { focusRequester.requestFocus() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // مقبض: اسحب للأسفل لإغلاق القائمة
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 60f) onClose() },
                        onVerticalDrag = { _, d -> total += d }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.4f))
            )
        }

        // حقل البحث
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(48.dp)
                .glass(RoundedCornerShape(18.dp))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { filtered.firstOrNull()?.let(onLaunch) }
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                text = "ابحث في هاتفك",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 16.sp
                            )
                        }
                        inner()
                    }
                }
            )
        }

        if (filtered.isEmpty() && apps.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد نتائج", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
            }
        }

        val tile = settings.tileDp.dp
        LazyVerticalGrid(
            columns = GridCells.Fixed(settings.columns),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Icon3D(app, tile, settings.labels) { onLaunch(app) }
                }
            }
        }
    }
}
