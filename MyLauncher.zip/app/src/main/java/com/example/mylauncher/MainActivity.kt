package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// معلومات كل تطبيق: اسمه، اسم الحزمة، أيقونته
data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LauncherScreen()
        }
    }
}

// تحميل كل التطبيقات القابلة للفتح من النظام
fun loadApps(pm: PackageManager): List<AppInfo> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                icon = it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun LauncherScreen() {
    val context = LocalContext.current
    val apps = remember { loadApps(context.packageManager) }
    var showDrawer by remember { mutableStateOf(false) }

    // زر الرجوع يغلق قائمة التطبيقات
    BackHandler(enabled = showDrawer) { showDrawer = false }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E12))
            .pointerInput(Unit) {
                // السحب للأعلى يفتح القائمة، وللأسفل يغلقها
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount < -20) showDrawer = true
                    if (dragAmount > 20) showDrawer = false
                }
            }
    ) {
        if (showDrawer) {
            AppDrawer(apps) { app ->
                context.packageManager.getLaunchIntentForPackage(app.packageName)
                    ?.let { context.startActivity(it) }
                showDrawer = false
            }
        } else {
            HomeScreen()
        }
    }
}

@Composable
fun HomeScreen() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    // تحديث الساعة كل ثانية
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
            color = Color.White,
            fontSize = 84.sp
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
            color = Color(0xFFB0B0BC),
            fontSize = 20.sp
        )
        Spacer(Modifier.size(48.dp))
        Text(
            text = "اسحب للأعلى لعرض التطبيقات",
            color = Color(0xFF6C6C7A),
            fontSize = 14.sp
        )
    }
}

@Composable
fun AppDrawer(apps: List<AppInfo>, onClick: (AppInfo) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClick(app) }
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(Modifier.width(16.dp))
                Text(text = app.label, color = Color.White, fontSize = 18.sp)
            }
        }
    }
}
