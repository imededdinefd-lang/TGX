package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// معلومات كل تطبيق: اسمه، اسم الحزمة، أيقونته
data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap
)

class MainActivity : ComponentActivity() {

    // يزداد عند الضغط على زر Home، فتُغلق قائمة التطبيقات
    private var homeEvent by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // واجهة بملء الشاشة خلف شريط الحالة وشريط التنقل
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            LauncherScreen(homeEvent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeEvent++
    }
}

// ---------------------------------------------------------------------------
// تحميل التطبيقات
// ---------------------------------------------------------------------------

fun loadApps(pm: PackageManager, self: String): List<AppInfo> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != self }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                icon = it.loadIcon(pm).toBitmap(160, 160).asImageBitmap()
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

// اختيار تطبيقات الشريط السفلي: الهاتف، الرسائل، الكاميرا، المتصفح
fun resolveDock(pm: PackageManager, apps: List<AppInfo>): List<AppInfo> {
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
    )
    val result = mutableListOf<AppInfo>()
    for (i in intents) {
        val pkg = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val app = apps.firstOrNull { it.packageName == pkg }
        if (app != null && app !in result) result.add(app)
    }
    // إن لم نجد أربعة تطبيقات نكمل من أول القائمة
    if (result.size < 4 && apps.isNotEmpty()) {
        for (app in apps) {
            if (result.size >= 4) break
            if (app !in result) result.add(app)
        }
    }
    return result
}

// ---------------------------------------------------------------------------
// التأثيرات: زجاج + خلفية
// ---------------------------------------------------------------------------

// طابع زجاجي: تعبئة شفافة متدرجة + حد لامع + ظل ناعم
fun Modifier.glass(shape: Shape, strength: Float = 1f): Modifier = this
    .shadow(
        elevation = 14.dp,
        shape = shape,
        ambientColor = Color.Black.copy(alpha = 0.35f),
        spotColor = Color.Black.copy(alpha = 0.45f)
    )
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.22f * strength),
                Color.White.copy(alpha = 0.07f * strength)
            )
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.60f),
                Color.White.copy(alpha = 0.06f),
                Color.White.copy(alpha = 0.28f)
            )
        ),
        shape
    )

// خلفية داكنة بتوهجات ملونة ليظهر الزجاج فوقها
@Composable
fun AuroraBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Color(0xFF07070D))
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            val c = Offset(size.width * cx, size.height * cy)
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r),
                radius = r,
                center = c
            )
        }
        blob(Color(0xFF6C4DFF).copy(alpha = 0.55f), 0.10f, 0.15f, size.width * 1.0f)
        blob(Color(0xFF00B8D9).copy(alpha = 0.40f), 0.95f, 0.45f, size.width * 0.9f)
        blob(Color(0xFFFF4D8D).copy(alpha = 0.30f), 0.30f, 0.95f, size.width * 1.0f)
    }
}

// أيقونة العدسة المكبرة (مرسومة بالكود)
@Composable
fun SearchGlyph() {
    Canvas(Modifier.size(20.dp)) {
        val w = 2.dp.toPx()
        val c = Color.White.copy(alpha = 0.8f)
        drawCircle(
            color = c,
            radius = size.width * 0.32f,
            center = Offset(size.width * 0.42f, size.height * 0.42f),
            style = Stroke(width = w)
        )
        drawLine(
            color = c,
            start = Offset(size.width * 0.66f, size.height * 0.66f),
            end = Offset(size.width * 0.92f, size.height * 0.92f),
            strokeWidth = w,
            cap = StrokeCap.Round
        )
    }
}

// ---------------------------------------------------------------------------
// أيقونة ثلاثية الأبعاد: قاعدة سميكة + لوح زجاجي لامع + لمعة ضوء
// ---------------------------------------------------------------------------

@Composable
fun Icon3D(app: AppInfo, tile: Dp, showLabel: Boolean, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.90f else 1f, label = "press")
    val currentClick by rememberUpdatedState(onClick)
    val shape = RoundedCornerShape(tile * 0.30f)

    Column(
        modifier = Modifier
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { currentClick() }
                )
            }
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
            contentAlignment = Alignment.TopCenter
        ) {
            // السُّمك: لوح داكن أسفل الأيقونة يعطي إحساس العمق
            Box(
                Modifier
                    .padding(top = 4.dp)
                    .size(tile)
                    .clip(shape)
                    .background(Color.Black.copy(alpha = 0.40f))
            )
            // اللوح الزجاجي العلوي
            Box(
                modifier = Modifier
                    .size(tile)
                    .shadow(8.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(shape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.34f),
                                Color.White.copy(alpha = 0.10f)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.75f),
                                Color.White.copy(alpha = 0.05f),
                                Color.White.copy(alpha = 0.30f)
                            )
                        ),
                        shape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(tile * 0.74f)
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            // لمعة من أعلى اليسار وظل في أسفل اليمين، فقط فوق رسم الأيقونة
                            drawRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.38f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.28f)
                                    ),
                                    start = Offset.Zero,
                                    end = Offset(size.width, size.height)
                                ),
                                blendMode = BlendMode.SrcAtop
                            )
                        }
                )
            }
        }
        if (showLabel) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = app.label,
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(tile + 12.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// الشاشات
// ---------------------------------------------------------------------------

@Composable
fun LauncherScreen(homeEvent: Int) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val pm = context.packageManager

    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var showDrawer by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    // تحميل التطبيقات في الخلفية حتى لا تتجمد الشاشة
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(pm, context.packageName) }
    }
    // زر Home يغلق قائمة التطبيقات
    LaunchedEffect(homeEvent) { showDrawer = false }
    // تفريغ البحث عند إغلاق القائمة
    LaunchedEffect(showDrawer) { if (!showDrawer) query = "" }
    BackHandler(enabled = showDrawer) { showDrawer = false }

    val dock = remember(apps) { resolveDock(pm, apps) }

    fun launch(app: AppInfo) {
        focusManager.clearFocus()
        pm.getLaunchIntentForPackage(app.packageName)?.let { context.startActivity(it) }
        showDrawer = false
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()

        AnimatedVisibility(
            visible = !showDrawer,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // السحب للأعلى يفتح القائمة
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total < -80f) {
                                    focusSearch = false
                                    showDrawer = true
                                }
                            },
                            onVerticalDrag = { _, d -> total += d }
                        )
                    }
            ) {
                HomeScreen(
                    dock = dock,
                    onOpenSearch = {
                        focusSearch = true
                        showDrawer = true
                    },
                    onLaunch = { launch(it) }
                )
            }
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = fadeIn() + slideInVertically { it / 8 },
            exit = fadeOut() + slideOutVertically { it / 8 }
        ) {
            AppDrawer(
                apps = apps,
                query = query,
                onQuery = { query = it },
                autoFocus = focusSearch,
                onClose = {
                    focusManager.clearFocus()
                    showDrawer = false
                },
                onLaunch = { launch(it) }
            )
        }
    }
}

@Composable
fun HomeScreen(dock: List<AppInfo>, onOpenSearch: () -> Unit, onLaunch: (AppInfo) -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 32.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
                color = Color.White,
                fontSize = 88.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 20.sp
            )
        }

        // شريط البحث الزجاجي
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 14.dp)
                .height(54.dp)
                .glass(RoundedCornerShape(27.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onOpenSearch
                )
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(12.dp))
            Text(
                text = "ابحث في هاتفك",
                color = Color.White.copy(alpha = 0.65f),
                fontSize = 16.sp
            )
        }

        // الشريط السفلي الزجاجي
        if (dock.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 16.dp)
                    .glass(RoundedCornerShape(34.dp))
                    .padding(vertical = 14.dp, horizontal = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                dock.forEach { app ->
                    Icon3D(app, 60.dp, false) { onLaunch(app) }
                }
            }
        }
    }
}

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    query: String,
    onQuery: (String) -> Unit,
    autoFocus: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit
) {
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps
        else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (autoFocus) runCatching { focusRequester.requestFocus() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // مقبض: اسحب للأسفل لإغلاق القائمة
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 60f) onClose() },
                        onVerticalDrag = { _, d -> total += d }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.4f))
            )
        }

        // حقل البحث الزجاجي
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(54.dp)
                .glass(RoundedCornerShape(27.dp))
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(12.dp))
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { filtered.firstOrNull()?.let(onLaunch) }
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                text = "ابحث في هاتفك",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 16.sp
                            )
                        }
                        inner()
                    }
                }
            )
        }

        if (filtered.isEmpty() && apps.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد نتائج", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Icon3D(app, 60.dp, true) { onLaunch(app) }
                }
            }
        }
    }
}
