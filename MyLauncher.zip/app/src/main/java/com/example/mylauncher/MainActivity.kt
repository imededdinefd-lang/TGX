package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// معلومات كل تطبيق: اسمه، حزمته، صورة الأيقونة الجاهزة، ولونه الغالب
@androidx.compose.runtime.Immutable
data class AppInfo(
    val label: String,
    val packageName: String,
    val tile: ImageBitmap,
    val accent: Int
)

class MainActivity : ComponentActivity() {

    // يزداد عند الضغط على Home، فتُغلق قائمة التطبيقات
    private var homeEvent by mutableIntStateOf(0)

    // يزداد عند العودة للواجهة، فنعيد قراءة الإعدادات والتطبيقات
    private var resumeEvent by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            LauncherScreen(homeEvent, resumeEvent)
        }
    }

    override fun onResume() {
        super.onResume()
        LauncherMotionSystem.refresh(this)
        resumeEvent++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeEvent++
    }
}

// ---------------------------------------------------------------------------
// تحميل التطبيقات (مع ذاكرة مؤقتة: تُرسم كل أيقونة مرة واحدة فقط)
// ---------------------------------------------------------------------------

object IconCache {
    val map = HashMap<String, AppInfo>()
}

fun loadApps(pm: PackageManager, self: String): List<AppInfo> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != self }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val pkg = ri.activityInfo.packageName
            IconCache.map.getOrPut(pkg) {
                val raw = ri.loadIcon(pm).toBitmap(192, 192)
                val res = IconRenderer.render(raw)
                AppInfo(ri.loadLabel(pm).toString(), pkg, res.bitmap.asImageBitmap(), res.accent)
            }
        }
        .sortedBy { it.label.lowercase() }
}

// اختيار تطبيقات الشريط السفلي: الهاتف، الرسائل، الكاميرا، المتصفح
fun resolveDock(pm: PackageManager, apps: List<AppInfo>, count: Int): List<AppInfo> {
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
    )
    val result = mutableListOf<AppInfo>()
    for (i in intents) {
        val pkg = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val app = apps.firstOrNull { it.packageName == pkg }
        if (app != null && app !in result) result.add(app)
    }
    // إن لم نجد العدد المطلوب نكمل من أول القائمة
    for (app in apps) {
        if (result.size >= count) break
        if (app !in result) result.add(app)
    }
    return result.take(count)
}

// ---------------------------------------------------------------------------
// أيقونة التطبيق: صورة جاهزة + تأثير ضغط خفيف
// ---------------------------------------------------------------------------

@Composable
fun Icon3D(
    app: AppInfo,
    tile: Dp,
    showLabel: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    // انكماش زنبركي من LauncherMotionSystem
    val scale by animateFloatAsState(
        targetValue = if (pressed) LauncherMotionSystem.PRESS_SCALE else 1f,
        animationSpec = LauncherMotionSystem.press(),
        label = "press"
    )
    val currentClick by rememberUpdatedState(onClick)
    val currentLong by rememberUpdatedState(onLongClick)

    Column(
        modifier = Modifier.pointerInput(app.packageName) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onLongPress = { currentLong?.invoke() },
                onTap = { currentClick() }
            )
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.tile,
            contentDescription = app.label,
            modifier = Modifier
                .size(tile * IconRenderer.SCALE)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
        )
        if (showLabel) {
            Text(
                text = app.label,
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(tile + 14.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// الشاشات
// ---------------------------------------------------------------------------

@Composable
fun LauncherScreen(homeEvent: Int, resumeEvent: Int) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val pm = context.packageManager

    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var showDrawer by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var homePkgs by remember { mutableStateOf(Prefs.loadHome(context)) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    val settings = remember(resumeEvent) { Prefs.load(context) }

    // تحميل التطبيقات في الخلفية (الأيقونات المرسومة سابقاً تُؤخذ من الذاكرة)
    LaunchedEffect(resumeEvent) {
        apps = withContext(Dispatchers.Default) { loadApps(pm, context.packageName) }
    }
    LaunchedEffect(homeEvent) {
        showDrawer = false
        showMenu = false
        menuApp = null
    }
    LaunchedEffect(showDrawer) { if (!showDrawer) query = "" }
    BackHandler(enabled = showDrawer) { showDrawer = false }
    BackHandler(enabled = showMenu) { showMenu = false }
    BackHandler(enabled = menuApp != null) { menuApp = null }

    val dock = remember(apps, settings.dockCount) { resolveDock(pm, apps, settings.dockCount) }

    fun launch(app: AppInfo) {
        focusManager.clearFocus()
        // نفتح التطبيق في مهمته الخاصة، ونترك واجهتنا حيّة في الخلفية (لا finish ولا CLEAR_TASK)
        pm.getLaunchIntentForPackage(app.packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            context.startActivity(it)
        }
        showDrawer = false
    }

    fun setHome(list: List<String>) {
        homePkgs = list
        Prefs.saveHome(context, list)
    }

    // تطبيقات الشاشة الرئيسية بالترتيب المحفوظ (نتجاهل ما أُلغي تثبيته)
    val homeApps = remember(apps, homePkgs) {
        val byPkg = apps.associateBy { it.packageName }
        homePkgs.mapNotNull { byPkg[it] }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(showDrawer) {
                // ضغطتان على مكان فارغ من الشاشة الرئيسية
                if (!showDrawer) {
                    detectTapGestures(onDoubleTap = {
                        GestureService.perform(context, Prefs.getInt(context, "gDouble", GestureAction.NONE))
                    })
                }
            }
    ) {
        AuroraBackground(settings.theme)

        AnimatedVisibility(
            visible = !showDrawer,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // الضغط المطوّل على مكان فارغ يفتح الإعدادات
                        detectTapGestures(
                            onLongPress = {
                                context.startActivity(Intent(context, SettingsActivity::class.java))
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        // السحب للأعلى يفتح القائمة
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total < -80f) {
                                    focusSearch = false
                                    showDrawer = true
                                }
                            },
                            onVerticalDrag = { _, d -> total += d }
                        )
                    }
            ) {
                HomeScreen(
                    dock = dock,
                    homeApps = homeApps,
                    tile = settings.tileDp.dp,
                    onLongPress = { menuApp = it },
                    onOpenSearch = {
                        focusSearch = true
                        showDrawer = true
                    },
                    onLaunch = { launch(it) }
                )
                // زر القائمة (إعدادات الواجهة + اختيار الشاشة الرئيسية)
                MenuButton(
                    onClick = { showMenu = true },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 12.dp, end = 20.dp)
                )
                if (showMenu) {
                    HomeMenu(
                        onSettings = {
                            showMenu = false
                            context.startActivity(Intent(context, SettingsActivity::class.java))
                        },
                        onHomeChooser = {
                            showMenu = false
                            openHomeChooser(context)
                        },
                        onDismiss = { showMenu = false }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = fadeIn() + slideInVertically { it / 10 },
            exit = fadeOut() + slideOutVertically { it / 10 }
        ) {
            AppDrawer(
                apps = apps,
                settings = settings,
                query = query,
                onQuery = { query = it },
                autoFocus = focusSearch,
                onClose = {
                    focusManager.clearFocus()
                    showDrawer = false
                },
                onLaunch = { launch(it) },
                onLongPress = { menuApp = it }
            )
        }

        // قائمة الضغط المطوّل على تطبيق
        menuApp?.let { app ->
            AppMenu(
                app = app,
                inHome = app.packageName in homePkgs,
                onToggleHome = {
                    if (app.packageName in homePkgs) setHome(homePkgs - app.packageName)
                    else setHome(homePkgs + app.packageName)
                    menuApp = null
                },
                onInfo = {
                    menuApp = null
                    context.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")
                        )
                    )
                },
                onUninstall = {
                    menuApp = null
                    context.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    )
                },
                onDismiss = { menuApp = null }
            )
        }
    }
}

@Composable
fun HomeScreen(
    dock: List<AppInfo>,
    homeApps: List<AppInfo>,
    tile: Dp,
    onLongPress: (AppInfo) -> Unit,
    onOpenSearch: () -> Unit,
    onLaunch: (AppInfo) -> Unit
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 32.dp, end = 32.dp, top = 56.dp)
        ) {
            Text(
                text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
                color = Color.White,
                fontSize = 64.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 18.sp
            )
        }

        // شبكة الشاشة الرئيسية (صفحات)
        HomeGrid(
            apps = homeApps,
            tile = tile,
            onLaunch = onLaunch,
            onLongPress = onLongPress,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        )

        // مستطيل البحث: صغير بحواف منحنية في وسط الشاشة
        Row(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 12.dp)
                .fillMaxWidth(0.72f)
                .height(46.dp)
                .glass(RoundedCornerShape(18.dp))
                .tappable(onOpenSearch)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            Text(
                text = "ابحث في هاتفك",
                color = Color.White.copy(alpha = 0.65f),
                fontSize = 15.sp
            )
        }

        // الشريط السفلي: أضيق، يلتف حول الأيقونات فقط
        if (dock.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 16.dp)
                    .glass(RoundedCornerShape(26.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                dock.forEach { app ->
                    Icon3D(app, 48.dp, false) { onLaunch(app) }
                }
            }
        }
    }
}

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    settings: LauncherSettings,
    query: String,
    onQuery: (String) -> Unit,
    autoFocus: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps
        else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (autoFocus) runCatching { focusRequester.requestFocus() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // مقبض: اسحب للأسفل لإغلاق القائمة
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 60f) onClose() },
                        onVerticalDrag = { _, d -> total += d }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.4f))
            )
        }

        // حقل البحث
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(48.dp)
                .glass(RoundedCornerShape(18.dp))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchGlyph()
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { filtered.firstOrNull()?.let(onLaunch) }
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                text = "ابحث في هاتفك",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 16.sp
                            )
                        }
                        inner()
                    }
                }
            )
        }

        if (filtered.isEmpty() && apps.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد نتائج", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
            }
        }

        val tile = settings.tileDp.dp
        LazyVerticalGrid(
            columns = GridCells.Fixed(settings.columns),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Icon3D(app, tile, settings.labels, { onLongPress(app) }) { onLaunch(app) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// قائمة الشاشة الرئيسية
// ---------------------------------------------------------------------------

// زر زجاجي دائري بثلاث نقاط
@Composable
fun MenuButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(40.dp)
            .glass(CircleShape)
            .tappable(onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            val c = Color.White.copy(alpha = 0.85f)
            val r = 2.dp.toPx()
            for (i in 0..2) {
                drawCircle(c, r, Offset(size.width / 2f, size.height * (0.15f + 0.35f * i)))
            }
        }
    }
}

// نافذة زجاجية صغيرة تحتوي الخيارات
@Composable
fun HomeMenu(onSettings: () -> Unit, onHomeChooser: () -> Unit, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().tappable(onDismiss)) {
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 64.dp, end = 20.dp)
                .width(260.dp)
                .glass(RoundedCornerShape(20.dp))
                .padding(vertical = 6.dp)
        ) {
            MenuItem("إعدادات الواجهة", onSettings)
            MenuItem("الشاشة الرئيسية الافتراضية", onHomeChooser)
        }
    }
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 15.sp,
        modifier = Modifier
            .fillMaxWidth()
            .tappable(onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp)
    )
}

// ---------------------------------------------------------------------------
// شبكة الشاشة الرئيسية (صفحات قابلة للتمرير)
// ---------------------------------------------------------------------------
@Composable
fun HomeGrid(
    apps: List<AppInfo>,
    tile: Dp,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier) {
        val cols = 4
        val cellH = tile * IconRenderer.SCALE + 22.dp
        val rows = ((maxHeight - 24.dp) / cellH).toInt().coerceIn(1, 6)
        val perPage = cols * rows
        val pageCount = maxOf(1, (apps.size + perPage - 1) / perPage)

        if (apps.isEmpty()) {
            Text(
                text = "اضغط مطوّلاً على أي تطبيق في القائمة لإضافته هنا",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 48.dp)
            )
        } else {
            val pagerState = rememberPagerState(pageCount = { pageCount })
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                val start = page * perPage
                val pageApps = apps.drop(start).take(perPage)
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    for (r in 0 until rows) {
                        Row(Modifier.fillMaxWidth().height(cellH)) {
                            for (c in 0 until cols) {
                                val app = pageApps.getOrNull(r * cols + c)
                                Box(
                                    Modifier.weight(1f).height(cellH),
                                    contentAlignment = Alignment.TopCenter
                                ) {
                                    if (app != null) {
                                        Icon3D(app, tile, true, { onLongPress(app) }) { onLaunch(app) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (pageCount > 1) {
                PageDots(
                    current = pagerState.currentPage,
                    count = pageCount,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
fun PageDots(current: Int, count: Int, modifier: Modifier = Modifier) {
    Row(
        modifier
            .glass(RoundedCornerShape(50), 0.6f)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0 until count) {
            Box(
                Modifier
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.4f))
            )
        }
    }
}

// قائمة الضغط المطوّل على تطبيق
@Composable
fun AppMenu(
    app: AppInfo,
    inHome: Boolean,
    onToggleHome: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .tappable(onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(280.dp)
                .glass(RoundedCornerShape(26.dp))
                .tappable { }
                .padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                bitmap = app.tile,
                contentDescription = app.label,
                modifier = Modifier.size(64.dp * IconRenderer.SCALE)
            )
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            MenuItem(
                if (inHome) "إزالة من الشاشة الرئيسية" else "إضافة إلى الشاشة الرئيسية",
                onToggleHome
            )
            MenuItem("معلومات التطبيق", onInfo)
            MenuItem("إلغاء التثبيت", onUninstall)
        }
    }
}
