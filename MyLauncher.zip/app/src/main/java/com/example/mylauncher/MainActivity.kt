package com.example.mylauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherHome(resumeTick) }
    }
}

@Composable
private fun LauncherHome(resumeTick: Int) {
    val context = LocalContext.current
    var settings by remember { mutableStateOf(Prefs.load(context)) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var drawerOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()

    fun refreshApps() {
        scope.launch {
            loading = apps.isEmpty()
            val result = AppRepo.load(context)
            apps = result
            loading = false
        }
    }
    LaunchedEffect(resumeTick) {
        settings = Prefs.load(context)
        refreshApps()
    }
    BackHandler(drawerOpen) { drawerOpen = false; search = "" }

    val bg = Prefs.background(settings.theme)
    val accent = Prefs.accent(settings.theme)
    val filtered = remember(apps, search) {
        if (search.isBlank()) apps else apps.filter { it.label.contains(search.trim(), true) }
    }

    Box(Modifier.fillMaxSize().background(bg).pointerInput(drawerOpen) {
        var drag = 0f
        detectVerticalDragGestures(
            onVerticalDrag = { _, amount -> drag += amount },
            onDragEnd = {
                if (!drawerOpen && drag < -72f) drawerOpen = true
                else if (drawerOpen && drag > 72f) drawerOpen = false
                drag = 0f
            },
            onDragCancel = { drag = 0f }
        )
    }) {
        if (!drawerOpen) {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(28.dp))
                Text(
                    text = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())),
                    color = Color.White.copy(alpha = .72f), fontSize = 14.sp
                )
                Text("${java.time.LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))}",
                    color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.weight(1f))
                Text("اسحب للأعلى لعرض التطبيقات", color = Color.White.copy(alpha = .62f), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
                        .background(Color.White.copy(alpha = settings.glassAlpha / 100f))
                        .clickable { drawerOpen = true },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("كل التطبيقات  ·  ${apps.size}", Modifier.padding(vertical = 18.dp), color = Color.White, fontSize = 15.sp)
                }
                Spacer(Modifier.height(22.dp))
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("التطبيقات", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("إغلاق", color = accent, modifier = Modifier.clickable { drawerOpen = false; search = "" }.padding(8.dp))
                }
                BasicTextField(
                    value = search, onValueChange = { search = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = .09f)).padding(horizontal = 16.dp, vertical = 15.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(accent),
                    decorationBox = { inner -> Box { if (search.isEmpty()) Text("ابحث عن تطبيق", color = Color.White.copy(alpha = .45f)); inner() } }
                )
                Spacer(Modifier.height(12.dp))
                if (loading && apps.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("جارٍ تحميل التطبيقات…", color = Color.White.copy(alpha = .65f)) }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(settings.columns), state = gridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(filtered, key = { it.component.flattenToShortString() }) { app ->
                            Column(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                    .clickable {
                                        runCatching { context.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                    }.padding(vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Image(app.icon, contentDescription = app.label, modifier = Modifier.size(settings.iconSize.dp))
                                Spacer(Modifier.height(7.dp))
                                Text(app.label, color = Color.White.copy(alpha = .94f), fontSize = 11.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
    }
}

