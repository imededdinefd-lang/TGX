package com.example.mylauncher

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.myLauncherDataStore by preferencesDataStore(name = "my_launcher_settings")

/** Preferences DataStore is the durable settings source. SharedPreferences is mirrored
 * for the launcher's existing synchronous readers (launcher/lock/accessibility service). */
object SettingsStore {
    val values: (Context) -> Flow<Map<String, Any>> = { context ->
        context.myLauncherDataStore.data.map { prefs ->
            prefs.asMap().entries.associate { it.key.name to it.value as Any }
        }
    }

    suspend fun putInt(context: Context, name: String, value: Int) {
        context.myLauncherDataStore.edit { it[intPreferencesKey(name)] = value }
    }

    suspend fun putBoolean(context: Context, name: String, value: Boolean) {
        context.myLauncherDataStore.edit { it[booleanPreferencesKey(name)] = value }
    }

    suspend fun putString(context: Context, name: String, value: String) {
        context.myLauncherDataStore.edit { it[stringPreferencesKey(name)] = value }
    }
}
